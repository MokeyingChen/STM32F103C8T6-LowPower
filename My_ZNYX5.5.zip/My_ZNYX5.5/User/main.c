#include "stm32f10x.h" // Device header

#include "Delay.h"
#include "MyRTC.h"
#include "Tick.h"
#include "BtnTIM.h"
#include "My_Flash.h"

#include "LED.h"
#include "Key.h"
#include "OLED.h"
#include "encoder.h"
#include "DHT11.h"
#include "ESP01S.h"
#include "HX711.h"
#include "JQ8900.h"
#include "Reflect.h"

void SystemClock_Recovery(void);
void MedBox_StateTake(void);
void MedBox_StateSend(void);
void OLED_ShowNormal(void);
void OLED_ShowSetting(void);
void OLED_ShowTiming(void);
void OLED_ShowWarning(void);
void OLED_ShowRecord(void);
void OLED_ShowAdjust(void);
void LowPowerWakeUp(uint8_t timeout);

volatile uint8_t uartflag = 0; // UART接收标志

volatile uint8_t deepsleepflag = 0; // 深睡眠标志

uint8_t temp = 0, humi = 0; // 温湿度变量
float weights;				// 重量变量
uint32_t taketime;			// 读取传感器时间间隔
uint32_t sendmedtime;		// 上报时间间隔
//uint8_t sendTimerFlag;		// 上报标志
uint32_t RTC_AlarmTime;		// RTC闹钟时间
uint32_t last_operation_time = 0;// 上次操作时间
uint8_t oledstate = 0; // OLED状态

/*药品状态报警推送标志*/
uint8_t nogoodwarnflag;
uint8_t nogood;
uint8_t noenoughwarnflag;
uint8_t noenough;

int main(void)
{
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);
	Tick_Init();
	OLED_Init();
	Store_Init();
	BtnTIM_Init();
	ESP01S_Usart();

	OLED_ShowString(24, 16, "WiFiInit...", 8);
	OLED_Update();
    Delay_ms(2000);
	esp_Init();
	//Initflag = 0;

	OLED_ShowString(24, 16, "ElseInit...", 8);
	OLED_Update();

	encoder_Init();
	MyRTC_Init();
	DHT11_Init();
	HX711_Init();
	Key_Init();
	LED_Init();
	JQ8900_Init();
	Reflect_Init();

	OLED_ShowInNormal();

	OLED_Update();

	last_operation_time = GetTick();

//	/*看门狗*/
//	if(RCC_GetFlagStatus(RCC_FLAG_IWDGRST)!=RESET)
//	{
//		RCC_ClearFlag();
//	}
//	IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);
//	IWDG_SetPrescaler(IWDG_Prescaler_64);
//	IWDG_SetReload(1249);//2000ms
//	IWDG_ReloadCounter();
//	IWDG_Enable();
     //正常13.4ma
	 //LowPower_ON();//6.7ma---6.2ma
	 	 	//__WFI();
	//PWR_EnterSTOPMode(PWR_Regulator_ON, PWR_STOPEntry_WFI); // 进入低功耗模式，等待中断唤醒1.8ma
	//PWR_EnterSTANDBYMode(); // 进入待机模式1.5
	while (1)
	{
		//IWDG_ReloadCounter();//喂狗

		MyRTC_GetTime(now_time);

        MedBox_StateTake(); // 读取传感器数据
		esp_Change_Timer(); // 处理中断数据
		Alaem_Check();		// 闹钟检查
        JQ8900_ReportStates(); // 语音播放状态处理

		if(encoder_get() || btnkey_get() || Key_get()||mediBoxStateFlags!=0) // 处理输入
		{
			last_operation_time = GetTick();
			if(oledstate == 1)
			{
				 oledstate = 0;
				 //uartflag = 0; // UART接收标志
				 //OLED_DeepSleep_Out();
                 OLED_ShallowSleep_Out();
			}
		}
        if (GetTick() - last_operation_time > 10000&&mediBoxStateFlags==0&&timestate!=Warning) // 若10秒无人操作且状态正常，则关闭显示进入低功耗模式
        {
			if(oledstate == 0)
			{
			oledstate = 1;
			OLED_ShallowSleep_Into();// 关闭显示
			//OLED_DeepSleep_Into();// 进入深睡眠
			}

        }


		

		switch (timestate) // 根据时间状态显示不同界面
		{
		case Normal:
			// OLED_ShowNum(0,0,TareValue,8,8);
			OLED_ShowNormal();

			break;

		case Setting:

			OLED_ShowSetting();
			MyRTC_ShowCursor();
			break;

		case Timing:

			OLED_ShowTiming();
			MyRTC_ShowCursor();
			break;

		case Warning:

			OLED_ShowWarning();
			break;

		case Record:

			OLED_ShowRecord();
			break;

		case Adjust:
			OLED_ShowAdjust();
			MyRTC_ShowCursor();
			break;
		}

		

		if (oledstate == 0)
		{
			OLED_Update();		   // 更新显示
		}
		
		

		if (Initflag == 1 | esp_timeout > 2) // 异常重连处理
		{
			if (esp_reconnect_flag == 1 | GetTick() - espinittime > 10000)
			{
				esp_reconnect();
			}
		}
		else if (Initflag == 0)
		{
			MedBox_StateSend(); // 上发数据到平台
		}

		 if(mediBoxStateFlags==0&&oledstate==1&&Initflag==0) // 若状态正常且OLED处于关闭状态，则进入低功耗模式
		 {
              // 进入低功耗模式

		 	 OLED_DeepSleep_Into();
		 	LowPowerWakeUp(10); // 10秒后再次唤醒
		 	LowPower_ON();
		 	PWR_EnterSTOPMode(PWR_Regulator_ON, PWR_STOPEntry_WFI);
		 	// deepsleepflag = 1;
		 	// while(deepsleepflag);
		 	LowPower_OFF();

		 	OLED_DeepSleep_Out(); // 唤醒后恢复
		 }

	}
}
 

void EXTI3_IRQHandler(void)
{
    if (EXTI_GetITStatus(EXTI_Line3) != RESET)
    {
        // 清除中断标志
        EXTI_ClearITPendingBit(EXTI_Line3);
        //uartflag = 1; // UART接收标志

        // 注意：此时系统已唤醒，但尚未恢复时钟和 UART。
    }
}

void RTCAlarm_IRQHandler(void)
{
	if(RTC_GetFlagStatus(RTC_FLAG_ALR) == SET)
	{
		EXTI_ClearITPendingBit(EXTI_Line17);
		RTC_ClearITPendingBit(RTC_FLAG_ALR);
		//LowPowerWakeUp(10); // 10秒后再次唤醒// 唤醒后关闭低功耗模式
          //uartflag = 1; 
	}
}

void LowPowerWakeUp(uint8_t timeout)
{
	// 低功耗唤醒处理
	RTC_AlarmTime = RTC_GetCounter()+timeout; // 设置timeout秒后触发闹钟
	RTC_WaitForLastTask();
	RTC_SetAlarm(RTC_AlarmTime);
	RTC_WaitForLastTask();
}



void SystemClock_Recovery(void)
{
    // 1. 使能 HSE 并等待稳定
    RCC_HSEConfig(RCC_HSE_ON);
    while (!RCC_GetFlagStatus(RCC_FLAG_HSERDY));
    
    // 2. 配置 PLL 时钟源为 HSE，倍频因子（例如 9 倍，HSE=8MHz -> 72MHz）
    RCC_PLLConfig(RCC_PLLSource_HSE_Div1, RCC_PLLMul_9);
    
    // 3. 使能 PLL 并等待稳定
    RCC_PLLCmd(ENABLE);
    while (!RCC_GetFlagStatus(RCC_FLAG_PLLRDY));
    
    // 4. 设置 Flash 等待周期（72MHz 时需要 2 个等待周期）
    FLASH_SetLatency(FLASH_Latency_2);
    FLASH_PrefetchBufferCmd(ENABLE);  // 可选，提高效率
    
    // 5. 切换系统时钟到 PLL 输出
    RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);
    while (RCC_GetSYSCLKSource() != 0x08);  // 0x08 表示 PLL 为系统时钟源
}









/*定时读取药箱传感器数据，阈值监测，报警推送*/
void MedBox_StateTake(void)
{
	if (RTC_GetCounter() - taketime > 3)
	{
		taketime = RTC_GetCounter();
		DHT11_ReadData(&temp, &humi);

		if (temp >= tempInThr)
		{
			mediBoxStateFlags |= 2;

			if (nogoodwarnflag == 0 && nogood == 0 && Initflag == 0)
			{
				ESP01S_SendNoGood(1);
				nogoodwarnflag = 1;
			}
			else if (nogoodwarnflag == 1 && nogood == 0 && Initflag == 0)
			{
				ESP01S_SendNoGood(0);
				nogood = 1;
			}
		}
		else
		{

			mediBoxStateFlags &= 13;
		}
		if (humi >= humiInThr)
		{
			mediBoxStateFlags |= 4;

			if (nogoodwarnflag == 0 && nogood == 0 && Initflag == 0)
			{
				ESP01S_SendNoGood(1);
				nogoodwarnflag = 1;
			}
			else if (nogoodwarnflag == 1 && nogood == 0 && Initflag == 0)
			{
				ESP01S_SendNoGood(0);
				nogood = 1;
			}
		}
		else
		{

			mediBoxStateFlags &= 11;
		}
		if ((!(temp >= tempInThr)) && (!(humi >= humiInThr)))
		{
			nogood = 0;
			nogoodwarnflag = 0;
		}

		weights = HX711_GetWeights();
		if (weights < 0)
			weights = 0.0;
		if (weights < weightInThr)
		{
			mediBoxStateFlags |= 8;
			if (noenoughwarnflag == 0 && noenough == 0 && Initflag == 0)
			{
				ESP01S_SendNoEnough(1);
				noenoughwarnflag = 1;
			}
			else if (noenoughwarnflag == 1 && noenough == 0 && Initflag == 0)
			{
				ESP01S_SendNoEnough(0);
				noenough = 1;
			}
		}
		else
		{
			noenoughwarnflag = 0;
			noenough = 0;
			mediBoxStateFlags &= 7;
		}
	}
}
/*定时上报药箱状态至云平台*/
void MedBox_StateSend(void)
{
	if (RTC_GetCounter() - sendmedtime > 60)
	{
		//led2_Turn();
		sendmedtime = RTC_GetCounter();
		ESP01S_SendMedState(temp, humi, weights, newRecord);
	}
}

void OLED_ShowNormal(void) // 正常模式显示
{
	MyRTC_ShowTime(now_time);

	OLED_ShowNum(72, 16, weights, 8, 4);
	//		OLED_ShowNum(112,16,(uint16_t)(fabs(weights)*10)%10,8,1);
	OLED_ShowNum(40, 32, temp, 8, 2);
	OLED_ShowNum(40, 48, humi, 8, 2);
}

void OLED_ShowSetting(void) // 设置模式显示
{
	MyRTC_ShowTime(setting_time);
	OLED_ShowChinese(0, 16, "药量阈值");
	char str[24];
	sprintf(str, ":%04d", weightInThr);
	OLED_ShowString(64, 16, str, 8);
	OLED_ShowString(104, 16, "g", 8);

	OLED_ShowChinese(0, 32, "温度阈值");
	sprintf(str, ":%02d", tempInThr);
	OLED_ShowString(64, 32, str, 8);
	OLED_ShowImage(88, 32, 16, 16, Diode);

	OLED_ShowChinese(0, 48, "湿度阈值");
	sprintf(str, ":%02d", humiInThr);
	OLED_ShowString(64, 48, str, 8);
	OLED_ShowString(88, 48, "%RH", 8);
}

void OLED_ShowTiming(void) // 定时模式显示
{

	OLED_ShowChinese(0, 0, "定时");
	OLED_ShowNum(32, 0, timerUse + 1, 8, 1);
	char str[16];
	sprintf(str, "%02d:%02d", alarm[timerUse].Hour, alarm[timerUse].Min);
	OLED_ShowString(48, 0, str, 8);

	OLED_ShowMed(timerUse); // 显示服药信息

	if (alarm[timerUse].Enable)
	{
		OLED_ShowChinese(112, 0, "开");
	}
	else
	{
		OLED_ShowChinese(112, 0, "关");
	}
	if (alarm[timerUse].Confirm == 0)
	{
		OLED_ShowChinese(96, 48, "状态");
	}
	else if (alarm[timerUse].Confirm == 1)
	{
		OLED_ShowChinese(96, 48, "未服");
	}
	else
	{
		OLED_ShowChinese(96, 48, "已服");
	}
}

void OLED_ShowWarning(void) // 报警界面显示
{
	OLED_ShowChinese(0, 0, "定时");
	OLED_ShowNum(32, 0, Warningtimer + 1, 8, 1);
	char str[16];
	sprintf(str, "%02d:%02d", alarm[Warningtimer].Hour, alarm[Warningtimer].Min);
	OLED_ShowString(48, 0, str, 8);
	OLED_ShowChinese(96, 0, "已到");

	OLED_ShowMed(Warningtimer);

	OLED_ShowChinese(0, 48, "请服用以上药品");
}

void OLED_ShowRecord(void) // 记录显示
{
	OLED_ShowChinese(16, 0, "最近服药记录");

	char str[32];
	for (uint8_t i = 1; i < 7; i++)
	{

		sprintf(str, "%04d-%02d-%02d %02d:%02d",
				Store_Data[i][0],
				Store_Data[i][1],
				Store_Data[i][2],
				Store_Data[i][3],
				Store_Data[i][4]);

		if (Store_Data[i][0] == 0)
		{
			OLED_ShowString(0, 16 + (i - 1) * 8, "                     ", 6);
		}
		else
		{
			OLED_ShowString(0, 16 + (i - 1) * 8, str, 6);

			if (Store_Data[i][5] == 2)
			{
				OLED_ShowString(104, 16 + (i - 1) * 8, "Yes", 6);
			}
			else if (Store_Data[i][5] == 1)
			{
				OLED_ShowString(110, 16 + (i - 1) * 8, "No", 6);
			}
			else
			{
				OLED_ShowString(110, 16 + (i - 1) * 8, " ", 6);
			}
		}
	}
}

void OLED_ShowAdjust(void) // 调整界面显示
{
	OLED_ShowChinese(0, 0, "音量设置");
	char str[24];
	sprintf(str, ":%02d", volumeadjust);
	OLED_ShowString(64, 0, str, 8);

	OLED_ShowChinese(0, 16, "去皮设置");

	OLED_ShowChinese(0, 32, "清空记录");

	OLED_ShowChinese(0, 48, "清空定时");
}
