#include "stm32f10x.h" // Device header

extern void SystemClock_Recovery(void);

_Bool Led_Status = 0;
void LED_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);

	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	GPIO_SetBits(GPIOB, GPIO_Pin_8);

	//  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);

	//  GPIO_InitTypeDef GPIO_InitStructure1;
	//  GPIO_InitStructure1.GPIO_Mode = GPIO_Mode_Out_PP;
	//  GPIO_InitStructure1.GPIO_Pin = GPIO_Pin_13;
	//  GPIO_InitStructure1.GPIO_Speed = GPIO_Speed_50MHz;
	//  GPIO_Init(GPIOC, &GPIO_InitStructure1);

	//  GPIO_SetBits(GPIOC, GPIO_Pin_13);
}

void LED1_ON(void)
{
	GPIO_ResetBits(GPIOB, GPIO_Pin_8);
	Led_Status = 1;
}

void LED1_OFF(void)
{
	GPIO_SetBits(GPIOB, GPIO_Pin_8);
	Led_Status = 0;
}

void LED1_Turn(void)
{
	if (GPIO_ReadOutputDataBit(GPIOB, GPIO_Pin_8) == 0)
	{
		GPIO_SetBits(GPIOB, GPIO_Pin_8);
	}
	else
	{
		GPIO_ResetBits(GPIOB, GPIO_Pin_8);
	}
}

void led2_Turn(void)
{
	if (GPIO_ReadOutputDataBit(GPIOC, GPIO_Pin_13) == 0)
	{
		GPIO_SetBits(GPIOC, GPIO_Pin_13);
	}
	else
	{
		GPIO_ResetBits(GPIOC, GPIO_Pin_13);
	}
}
void LowPower_ON(void)
{
	// GPIO_ResetBits(GPIOC, GPIO_Pin_13);
	 // 1. 关闭 UART
    USART_Cmd(USART2, DISABLE);
    // 2. 切换 PA3 为 EXTI 输入模式
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
    // 3. 使能 EXTI 和 NVIC
	EXTI_ClearITPendingBit(EXTI_Line3);
    EXTI->IMR |= EXTI_IMR_MR3;          // 或者使用 EXTI_Init 重新使能
    NVIC_EnableIRQ(EXTI3_IRQn);

}

void LowPower_OFF(void)
{
	// GPIO_SetBits(GPIOC, GPIO_Pin_13);
	 // 1. 禁用 EXTI 和 NVIC
    EXTI->IMR &= ~EXTI_IMR_MR3;
    NVIC_DisableIRQ(EXTI3_IRQn);
	
	SystemClock_Recovery();

    // 2. 切换 PA3 回 UART 模式
    GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
    

    USART_Cmd(USART2, ENABLE);


}
