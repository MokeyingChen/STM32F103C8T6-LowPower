#include "stm32f10x.h"                  // Device header
#include <time.h>
#include <stdio.h>
#include "MyRTC.h"
#include "OLED.h"
#include "Tick.h"
#include "Key.h"

int16_t weightInThr=0;//0~5000g
int8_t tempInThr=40;//0~50℃
int8_t humiInThr=65;//20~90%RH
uint16_t thr_buffer[3]={0};

SettingState settingState=hour;
TimeState lasttimestate=Normal;
AdjustState adjustState=volume;
TimeState timestate=Normal;
CursorPosition TimingCuPo[21]={  {32,15,39,15},{48,15,48+15,15},{72,15,72+15,15},  {112,15,127,15}, 
                                 {0,31,15,31}, {16,31,23,31}, {32,31,47,31},{48,31,63,31},
								 {64,31,79,31}, {80,31,87,31}, {96,31,111,31},{112,31,127,31},
								 {0,47,15,47}, {16,47,23,47}, {32,47,47,47},{48,47,63,47},
								 {64,47,79,47}, {80,47,87,47}, {96,47,111,47},{112,47,127,47},
                                                                 {127-31,63,127,63}  
};
CursorPosition SettingCuPo[9]={ {40,15,40+11,15},{40+18,15,40+18+11,15},{40+18+18,15,40+18+18+11,15},
	                            {34,7,34+23,7},  {64,7,64+11,7},        {64+17,7,64+17+11,7},
                                {72,31,72+31,31},{72,47,72+15,47},      {72,63,72+15,63}
};
CursorPosition AdjustCuPo[4]={ {72,15,72+15,15},
	                            {0,31,63,31},  
								{0,47,63,47},
								{0,63,63,63}
};
int16_t MyRTC_Time[]={2025,10,31,23,59,40};// 初始时间
int16_t now_time[6]={0};// 存储当前时间
int16_t setting_time[6]={0};//储存设置时间时刻值
int16_t buffer_time[6]={0};
void MyRTC_Init(void)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_BKP, ENABLE);

	PWR_BackupAccessCmd(ENABLE);

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);

    RTC_ClearITPendingBit(RTC_FLAG_ALR);

    RTC_WaitForLastTask();
    RTC_ITConfig(RTC_IT_ALR, ENABLE);
    RTC_WaitForLastTask();

	EXTI_InitTypeDef EXTI_InitStructure;
	EXTI_InitStructure.EXTI_Line = EXTI_Line17;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStructure);

    NVIC_InitTypeDef NVIC_InitStruct;
    NVIC_InitStruct.NVIC_IRQChannel = RTCAlarm_IRQn;
    NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
    NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 7;
    NVIC_InitStruct.NVIC_IRQChannelSubPriority = 0;
    NVIC_Init(&NVIC_InitStruct);

    

	if (BKP_ReadBackupRegister(BKP_DR1) != 0xa5a5)
	{
		RCC_LSEConfig(RCC_LSE_ON);
		while (RCC_GetFlagStatus(RCC_FLAG_LSERDY) == RESET)
			;

		RCC_RTCCLKConfig(RCC_RTCCLKSource_LSE);
		RCC_RTCCLKCmd(ENABLE);

		RTC_WaitForSynchro();
		RTC_WaitForLastTask();

		RTC_SetPrescaler(32768 - 1);
		RTC_WaitForLastTask();

		MyRTC_SetTime(MyRTC_Time);
		BKP_WriteBackupRegister(BKP_DR1, 0xa5a5);
	}
	else
	{
		RTC_WaitForSynchro();
		RTC_WaitForLastTask();
	}
}

void MyRTC_SetTime(int16_t Time[])
{
	time_t time_cnt;
	struct tm time_date;

	time_date.tm_year = Time[0] - 1900;
	time_date.tm_mon = Time[1] - 1;
	time_date.tm_mday = Time[2];
	time_date.tm_hour = Time[3];
	time_date.tm_min = Time[4];
	time_date.tm_sec = Time[5];

	time_cnt = mktime(&time_date) - 8 * 60 * 60;

	RTC_SetCounter(time_cnt);
	RTC_WaitForLastTask();
}

void MyRTC_GetTime(int16_t Time[])
{
	time_t time_cnt;
	struct tm time_date;

	time_cnt = RTC_GetCounter() + 8 * 60 * 60;
	time_date = *localtime(&time_cnt);

	Time[0] = time_date.tm_year + 1900;
	Time[1] = time_date.tm_mon + 1;
	Time[2] = time_date.tm_mday;
	Time[3] = time_date.tm_hour;
	Time[4] = time_date.tm_min;
	Time[5] = time_date.tm_sec;
}

void MyRTC_ShowTime(int16_t Time[]) // 显示时间
{
	char str[24];

	sprintf(str, "%04d-%02d-%02d", Time[0], Time[1], Time[2]);

	OLED_ShowString(34, 0, str, 6);

	sprintf(str, "%02d:%02d:%02d", Time[3], Time[4], Time[5]);

	OLED_ShowString(40, 8, str, 6);
}

void MyRTC_ShowCursor(void) // 光标闪烁
{
	static uint32_t startTime = 0;
	uint32_t diffTime = GetTick() - startTime;
	CursorPosition position;
	if (timestate == Setting)
	{
		if (diffTime > 1000)
		{
			startTime = GetTick();
			position = SettingCuPo[settingState];
			OLED_ClearLine(position.x0, position.y0, position.x1, position.y1);
		}
		else if (diffTime > 500)
		{
			position = SettingCuPo[settingState];
			OLED_DrawLine(position.x0, position.y0, position.x1, position.y1);
		}
	}
	else if (timestate == Timing)
	{
		if (diffTime > 1000)
		{
			startTime = GetTick();
			position = TimingCuPo[timingState];
			OLED_ClearLine(position.x0, position.y0, position.x1, position.y1);
		}
		else if (diffTime > 500)
		{
			position = TimingCuPo[timingState];
			OLED_DrawLine(position.x0, position.y0, position.x1, position.y1);
		}
	}

	else if (timestate == Adjust)
	{
		if (diffTime > 1000)
		{
			startTime = GetTick();
			position = AdjustCuPo[adjustState];
			OLED_ClearLine(position.x0, position.y0, position.x1, position.y1);
		}
		else if (diffTime > 500)
		{
			position = AdjustCuPo[adjustState];
			OLED_DrawLine(position.x0, position.y0, position.x1, position.y1);
		}
	}
}
