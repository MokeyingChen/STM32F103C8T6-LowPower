#include "stm32f10x.h" // Device header
#include "encoder.h"
#include "ESP01S.h"
#include "Tick.h"
#include "MyRTC.h"
#include "BtnTIM.h"
#include "Key.h"
#include "OLED.h"
#include "My_Flash.h"
#include "JQ8900.h"
#include "HX711.h"
#include <string.h>
#include "LED.h"

 volatile BtnState btnstate = Unpressed;
/*******************  旋转编码器（在正常界面下正转【右旋】进入记录（record）界面，反转进入调节（adjust）界面），
					   key1（在正常界面下按下跳转到设置（setting）界面）*******************************/
void encoder_Init(void)
{
	encoder_ButtonInit();
	RCC_APB2PeriphClockCmd(encoder_GPIO_CLK, ENABLE);
	RCC_APB2PeriphClockCmd(encoder_TIM_CLK, ENABLE);

	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = encoder_GPIO_PIN_A | encoder_GPIO_PIN_B;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(encoder_GPIO_PORT, &GPIO_InitStructure);

	TIM_InternalClockConfig(encoder_TIM_PORT);

	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStructure.TIM_Period = 65536 - 1; // ARR
	TIM_TimeBaseInitStructure.TIM_Prescaler = 2 - 1;  // PSC
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(encoder_TIM_PORT, &TIM_TimeBaseInitStructure);

	TIM_ICInitTypeDef TIM_ICInitStructure;
	TIM_ICStructInit(&TIM_ICInitStructure);
	TIM_ICInitStructure.TIM_Channel = encoder_TIM_Channel_A;
	TIM_ICInitStructure.TIM_ICFilter = 0xF;
	TIM_ICInitStructure.TIM_ICPolarity = TIM_ICPolarity_Rising;
	TIM_ICInit(encoder_TIM_PORT, &TIM_ICInitStructure);
	TIM_ICInitStructure.TIM_Channel = encoder_TIM_Channel_B;
	TIM_ICInitStructure.TIM_ICFilter = 0xF;
	TIM_ICInitStructure.TIM_ICPolarity = TIM_ICPolarity_Rising;
	TIM_ICInit(encoder_TIM_PORT, &TIM_ICInitStructure);
	TIM_EncoderInterfaceConfig(encoder_TIM_PORT, TIM_EncoderMode_TI1, TIM_ICPolarity_Rising, TIM_ICPolarity_Rising);
	TIM_Cmd(encoder_TIM_PORT, ENABLE);
	TIM_SetCounter(encoder_TIM_PORT, CNT_InitValue);
}

void encoder_ButtonInit(void)
{
	RCC_APB2PeriphClockCmd(encoder_button_CLK | RCC_APB2Periph_AFIO, ENABLE);

	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = encoder_button_PIN;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(encoder_button_PORT, &GPIO_InitStructure);

	GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource12);

	EXTI_InitTypeDef EXTI_InitStructure;
	EXTI_InitStructure.EXTI_Line = EXTI_Line12;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStructure);

	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn; // PB12属于EXTI15_10_IRQn
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 5;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}

uint8_t encoder_get(void)
{

	uint32_t count;

	count = TIM_GetCounter(encoder_TIM_PORT);

	if (count > CNT_InitValue) // 判断正转
	{
		foreward();
		TIM_SetCounter(encoder_TIM_PORT, CNT_InitValue);
		return 1;
	}
	else if (count < CNT_InitValue) // 判断反转
	{
		backward();
		TIM_SetCounter(encoder_TIM_PORT, CNT_InitValue);
		return 2;
	}

	return 0;
}

uint8_t btnkey_get(void)
{
	if (btnstate == Pressed) // 判断按键
	{
		btnstate = Unpressed;
		encoder_button();
		return 1;
	}
	return 0;
}


void foreward(void) // 正转执行任务
{
	if (timestate == Normal)
	{
		timestate = Record;
		OLED_Clear();
	}
	else if (timestate == Record)
	{
		//bug测试
//		LED1_Turn();
//		MyFLASH_ErasePages(ALARM_START_ADDRESS);
//	for (uint8_t j = 7; j < 10; j++)
//	{
//		for (uint8_t i = 0; i < 20; i++)
//		{
//			MyFLASH_ProgramHalfWord(ALARM_START_ADDRESS + i * 2 + (j - 7) * 2 * 20, Store_Data[j][i]);
//		}
//	}
	}
	else if (timestate == Adjust)
	{
		switch (adjustState)
		{
		case volume:
			timestate = Normal;
			OLED_ShowInNormal();

			break;
		case tare:
			adjustState--;
			break;

		case clearrecord:
			adjustState--;
			break;

		case cleartimer:
			adjustState--;
			break;
		}
	}
	else if (timestate == Setting)
	{
		switch (settingState)
		{
		case hour:
			setting_time[3]++;
			if (setting_time[3] > 23)
			{
				setting_time[3] = 0;
			}
			break;
		case min:
			setting_time[4]++;
			if (setting_time[4] > 59)
			{
				setting_time[4] = 0;
			}
			break;
		case sec:
			setting_time[5]++;
			if (setting_time[5] > 59)
			{
				setting_time[5] = 0;
			}
			break;
		case year:
			setting_time[0]++;
			break;
		case mon:
			if (setting_time[1] == 12)
			{
				setting_time[1] = 1;
			}
			else
			{
				setting_time[1]++;
			}
			break;
		case mday:
			if (setting_time[2] == 31)
			{
				setting_time[2] = 1;
			}
			else
			{
				setting_time[2]++;
			}
			break;

		case weightThr:
			weightInThr++;
			if (weightInThr > 5000)
			{
				weightInThr = 0;
			}
			break;
		case tempThr:
			tempInThr++;
			if (tempInThr > 50)
			{
				tempInThr = 0;
			}
			break;
		case humiThr:
			humiInThr++;
			if (humiInThr > 90)
			{
				humiInThr = 20;
			}
			break;
		}
	}
	else if (timestate == Timing)
	{
		switch (timingState)
		{
		case Timer:
			if (timerUse == Timer5)
			{
				timerUse = Timer1;
			}
			else
			{
				timerUse++;
			}
			break;
		case Hour:
			alarm[timerUse].Hour++;
			if (alarm[timerUse].Hour > 23)
			{
				alarm[timerUse].Hour = 0;
			}
			break;
		case Min:
			alarm[timerUse].Min++;
			if (alarm[timerUse].Min > 59)
			{
				alarm[timerUse].Min = 0;
			}
			break;
		case MedType1:
			alarm[timerUse].medType1++;
			if (alarm[timerUse].medType1 > MedBottle)
			{
				alarm[timerUse].medType1 = None;
			}

			break;
		case MedNum1:
			if (alarm[timerUse].medNum1 == '\0')
			{
				alarm[timerUse].medNum1 = 'A';
			}
			else if (alarm[timerUse].medNum1 == 'Z')
			{
				alarm[timerUse].medNum1 = '\0';
			}
			else
			{
				alarm[timerUse].medNum1++;
			}
			break;
		case Dosage1:
			alarm[timerUse].Dosage1++;
			if (alarm[timerUse].Dosage1 > 99)
			{
				alarm[timerUse].Dosage1 = 0;
			}
			break;
		case UnitType1:
			alarm[timerUse].unitType1++;
			if (alarm[timerUse].unitType1 > Milliliter)
			{
				alarm[timerUse].unitType1 = none;
			}
			break;
		case MedType2:
			alarm[timerUse].medType2++;
			if (alarm[timerUse].medType2 > MedBottle)
			{
				alarm[timerUse].medType2 = None;
			}
			break;
		case MedNum2:
			if (alarm[timerUse].medNum2 == '\0')
			{
				alarm[timerUse].medNum2 = 'A';
			}
			else if (alarm[timerUse].medNum2 == 'Z')
			{
				alarm[timerUse].medNum2 = '\0';
			}
			else
			{
				alarm[timerUse].medNum2++;
			}
			break;
		case Dosage2:
			alarm[timerUse].Dosage2++;
			if (alarm[timerUse].Dosage2 > 99)
			{
				alarm[timerUse].Dosage2 = 0;
			}
			break;
		case UnitType2:
			alarm[timerUse].unitType2++;
			if (alarm[timerUse].unitType2 > Milliliter)
			{
				alarm[timerUse].unitType2 = none;
			}
			break;
		case MedType3:
			alarm[timerUse].medType3++;
			if (alarm[timerUse].medType3 > MedBottle)
			{
				alarm[timerUse].medType3 = None;
			}
			break;
		case MedNum3:
			if (alarm[timerUse].medNum3 == '\0')
			{
				alarm[timerUse].medNum3 = 'A';
			}
			else if (alarm[timerUse].medNum3 == 'Z')
			{
				alarm[timerUse].medNum3 = '\0';
			}
			else
			{
				alarm[timerUse].medNum3++;
			}
			break;
		case Dosage3:
			alarm[timerUse].Dosage3++;
			if (alarm[timerUse].Dosage3 > 99)
			{
				alarm[timerUse].Dosage3 = 0;
			}
			break;
		case UnitType3:
			alarm[timerUse].unitType3++;
			if (alarm[timerUse].unitType3 > Milliliter)
			{
				alarm[timerUse].unitType3 = none;
			}
			break;
		case MedType4:
			alarm[timerUse].medType4++;
			if (alarm[timerUse].medType4 > MedBottle)
			{
				alarm[timerUse].medType4 = None;
			}
			break;
		case MedNum4:
			if (alarm[timerUse].medNum4 == '\0')
			{
				alarm[timerUse].medNum4 = 'A';
			}
			else if (alarm[timerUse].medNum4 == 'Z')
			{
				alarm[timerUse].medNum4 = '\0';
			}
			else
			{
				alarm[timerUse].medNum4++;
			}
			break;
		case Dosage4:
			alarm[timerUse].Dosage4++;
			if (alarm[timerUse].Dosage4 > 99)
			{
				alarm[timerUse].Dosage4 = 0;
			}
			break;
		case UnitType4:
			alarm[timerUse].unitType4++;
			if (alarm[timerUse].unitType4 > Milliliter)
			{
				alarm[timerUse].unitType4 = none;
			}
			break;
		case Enable:
			alarm[timerUse].Enable = !alarm[timerUse].Enable;
			if (alarm[timerUse].Enable == 1)
			{
				alarm[timerUse].Confirm = 0;
			}
			break;
		case Confirm:

			if (alarm[timerUse].Confirm != 0)
			{
				alarm[timerUse].Confirm = 0;
			}
			break;
		}
	}
}

void backward(void) // 反转执行任务
{
	if (timestate == Normal)
	{
		timestate = Adjust;
		OLED_Clear();
	}
	else if (timestate == Adjust)
	{
		switch (adjustState)
		{
		case volume:
			adjustState++;
			break;
		case tare:
			adjustState++;
			break;
		case clearrecord:
			adjustState++;
			break;
		case cleartimer:

			break;
		}
	}
	else if (timestate == Record)
	{
		timestate = Normal;
		OLED_ShowInNormal();
	}

	else if (timestate == Setting)
	{
		switch (settingState)
		{
		case hour:
			setting_time[3]--;
			if (setting_time[3] < 0)
			{
				setting_time[3] = 23;
			}
			break;
		case min:
			setting_time[4]--;
			if (setting_time[4] < 0)
			{
				setting_time[4] = 59;
			}
			break;
		case sec:
			setting_time[5]--;
			if (setting_time[5] < 0)
			{
				setting_time[5] = 59;
			}
			break;
		case year:
			if (setting_time[0] == 1970)
			{
				setting_time[0] = 1970;
			}
			else
			{
				setting_time[0]--;
			}
			break;
		case mon:
			if (setting_time[1] == 1)
			{
				setting_time[1] = 12;
			}
			else
			{
				setting_time[1]--;
			}
			break;
		case mday:
			if (setting_time[2] == 1)
			{
				setting_time[2] = 31;
			}
			else
			{
				setting_time[2]--;
			}
			break;
		case weightThr:
			weightInThr--;
			if (weightInThr < 0)
			{
				weightInThr = 5000;
			}
			break;
		case tempThr:
			tempInThr--;
			if (tempInThr < 0)
			{
				tempInThr = 50;
			}
			break;
		case humiThr:
			humiInThr--;
			if (humiInThr < 20)
			{
				humiInThr = 90;
			}
			break;
		}
	}
	else if (timestate == Timing)
	{
		switch (timingState)
		{
		case Timer:
			if (timerUse == Timer1)
			{
				timerUse = Timer5;
			}
			else
			{
				timerUse--;
			}
			break;
		case Hour:
			alarm[timerUse].Hour--;
			if (alarm[timerUse].Hour < 0)
			{
				alarm[timerUse].Hour = 23;
			}
			break;
		case Min:
			alarm[timerUse].Min--;
			if (alarm[timerUse].Min < 0)
			{
				alarm[timerUse].Min = 59;
			}
			break;
		case MedType1:

			if (alarm[timerUse].medType1 == None)
			{
				alarm[timerUse].medType1 = MedBottle;
			}
			else
			{
				alarm[timerUse].medType1--;
			}
			break;
		case MedNum1:
			if (alarm[timerUse].medNum1 == '\0')
			{
				alarm[timerUse].medNum1 = 'Z';
			}
			else if (alarm[timerUse].medNum1 == 'A')
			{
				alarm[timerUse].medNum1 = '\0';
			}
			else
			{
				alarm[timerUse].medNum1--;
			}
			break;
		case Dosage1:

			if (alarm[timerUse].Dosage1 == 0)
			{
				alarm[timerUse].Dosage1 = 99;
			}
			else
			{
				alarm[timerUse].Dosage1--;
			}
			break;
		case UnitType1:

			if (alarm[timerUse].unitType1 == none)
			{
				alarm[timerUse].unitType1 = Milliliter;
			}
			else
			{
				alarm[timerUse].unitType1--;
			}
			break;
		case MedType2:

			if (alarm[timerUse].medType2 == None)
			{
				alarm[timerUse].medType2 = MedBottle;
			}
			else
			{
				alarm[timerUse].medType2--;
			}
			break;
		case MedNum2:
			if (alarm[timerUse].medNum2 == '\0')
			{
				alarm[timerUse].medNum2 = 'Z';
			}
			else if (alarm[timerUse].medNum2 == 'A')
			{
				alarm[timerUse].medNum2 = '\0';
			}
			else
			{
				alarm[timerUse].medNum2--;
			}
			break;
		case Dosage2:

			if (alarm[timerUse].Dosage2 == 0)
			{
				alarm[timerUse].Dosage2 = 99;
			}
			else
			{
				alarm[timerUse].Dosage2--;
			}
			break;
		case UnitType2:

			if (alarm[timerUse].unitType2 == none)
			{
				alarm[timerUse].unitType2 = Milliliter;
			}
			else
			{
				alarm[timerUse].unitType2--;
			}
			break;
		case MedType3:

			if (alarm[timerUse].medType3 == None)
			{
				alarm[timerUse].medType3 = MedBottle;
			}
			else
			{
				alarm[timerUse].medType3--;
			}
			break;
		case MedNum3:
			if (alarm[timerUse].medNum3 == '\0')
			{
				alarm[timerUse].medNum3 = 'Z';
			}
			else if (alarm[timerUse].medNum3 == 'A')
			{
				alarm[timerUse].medNum3 = '\0';
			}
			else
			{
				alarm[timerUse].medNum3--;
			}
			break;
		case Dosage3:

			if (alarm[timerUse].Dosage3 == 0)
			{
				alarm[timerUse].Dosage3 = 99;
			}
			else
			{
				alarm[timerUse].Dosage3--;
			}
			break;
		case UnitType3:

			if (alarm[timerUse].unitType3 == none)
			{
				alarm[timerUse].unitType3 = Milliliter;
			}
			else
			{
				alarm[timerUse].unitType3--;
			}
			break;
		case MedType4:

			if (alarm[timerUse].medType4 == None)
			{
				alarm[timerUse].medType4 = MedBottle;
			}
			else
			{
				alarm[timerUse].medType4--;
			}
			break;
		case MedNum4:
			if (alarm[timerUse].medNum4 == '\0')
			{
				alarm[timerUse].medNum4 = 'Z';
			}
			else if (alarm[timerUse].medNum4 == 'A')
			{
				alarm[timerUse].medNum4 = '\0';
			}
			else
			{
				alarm[timerUse].medNum4--;
			}
			break;
		case Dosage4:

			if (alarm[timerUse].Dosage4 == 0)
			{
				alarm[timerUse].Dosage4 = 99;
			}
			else
			{
				alarm[timerUse].Dosage4--;
			}
			break;
		case UnitType4:

			if (alarm[timerUse].unitType4 == none)
			{
				alarm[timerUse].unitType4 = Milliliter;
			}
			else
			{
				alarm[timerUse].unitType4--;
			}
			break;
		case Enable:
			alarm[timerUse].Enable = !alarm[timerUse].Enable;
			if (alarm[timerUse].Enable == 1)
			{
				alarm[timerUse].Confirm = 0;
			}
			break;
		case Confirm:

			if (alarm[timerUse].Confirm != 0)
			{
				alarm[timerUse].Confirm = 0;
			}
			break;
		}
	}
}

void encoder_button(void) // 按键任务
{
	switch (timestate)
	{
	case Normal:

		MyRTC_GetTime(setting_time);
		memcpy(buffer_time, setting_time, sizeof(setting_time)); // 备份当前时间到设置时间缓存

		thr_buffer[0] = weightInThr;
		thr_buffer[1] = tempInThr;
		thr_buffer[2] = humiInThr;

		settingState = hour;
		timestate = Setting;
		OLED_Clear();
		break;

	case Setting:

		if (settingState == humiThr)
		{
			if (memcmp(buffer_time, setting_time, sizeof(setting_time)) != 0) // 判断时间是否更改，若更改则设置时间
			{
				MyRTC_SetTime(setting_time);
			}
			timestate = Normal;
			OLED_ShowInNormal();

			if (thr_buffer[0] != weightInThr | thr_buffer[1] != tempInThr | thr_buffer[2] != humiInThr) // 判断阈值是否更改，若更改则写入存储区
			{
				ThrAdd();
			}
		}
		else
		{
			settingState++;
		}
		break;

	case Timing:

		if (timingState == Confirm)
		{
			timestate = Normal;
			OLED_ShowInNormal();
			AlarmAdd();
		}
		else
		{
			//			if((timingState==MedType1&&alarm[timerUse].medType1==None)|(timingState==MedType2&&alarm[timerUse].medType2==None)|
			//				(timingState==MedType3&&alarm[timerUse].medType3==None)|(timingState==MedType4&&alarm[timerUse].medType4==None)){
			//				timingState+=4;
			//			}else{
			//			timingState++;
			//			}
			if ((timingState == MedType1 && alarm[timerUse].medType1 == None && alarm[timerUse].medType2 == None) |
				(timingState == MedType2 && alarm[timerUse].medType2 == None && alarm[timerUse].medType3 == None) |
				(timingState == MedType3 && alarm[timerUse].medType3 == None && alarm[timerUse].medType4 == None) |
				(timingState == MedType4 && alarm[timerUse].medType4 == None))
			{
				timingState = Confirm;
			}
			else
			{
				timingState++;
			}
		}
		break;

	case Warning:

		if (lasttimestate == Normal | lasttimestate == Warning)
		{
			timestate = Normal;
			OLED_ShowInNormal();
		}
		else
		{
			timestate = lasttimestate;
			OLED_Clear();
		}
		break;

	case Record:

		break;
	case Adjust:
		switch (adjustState)
		{
		case volume:
			if (volumeadjust < 30)
			{
				Volume_Plus();
				volumeadjust++;
			}
			break;

		case tare:
			GetMaoPi();
			break;

		case clearrecord:
			RecordStore_Clear();
			sprintf(newRecord, "%04d-%02d-%02d %02d:%02d %s",Store_Data[1][0],
			Store_Data[1][1],
			Store_Data[1][2],
			Store_Data[1][3],
			Store_Data[1][4], (Store_Data[1][5] == 2) ? "已服" : (Store_Data[1][5] == 1) ? "未服"
																																													 : "无");
			break;
		case cleartimer:
			memset(alarm, 0, sizeof(alarm));
			AlarmAdd();
		}
		break;
	}
}
