#ifndef __ENCODER_H
#define __ENCODER_H

typedef enum
{
    Unpressed,
    Pressed
} BtnState;
extern volatile BtnState btnstate;

#define BTN_DEBOUNCE_MS 20 // 20ms消抖时间

#define CNT_InitValue 32767

#define encoder_button_CLK RCC_APB2Periph_GPIOB
#define encoder_button_PIN GPIO_Pin_12
#define encoder_button_PORT GPIOB

#define encoder_GPIO_PORT GPIOA
#define encoder_GPIO_PIN_A GPIO_Pin_8
#define encoder_GPIO_PIN_B GPIO_Pin_9
#define encoder_GPIO_CLK RCC_APB2Periph_GPIOA

#define encoder_TIM_PORT TIM1
#define encoder_TIM_CLK RCC_APB2Periph_TIM1
#define encoder_TIM_Channel_A TIM_Channel_1
#define encoder_TIM_Channel_B TIM_Channel_2

void encoder_Init(void);
void encoder_ButtonInit(void);

uint8_t encoder_get(void);
uint8_t btnkey_get(void);

void foreward(void);
void backward(void);
void encoder_button(void);

#endif
