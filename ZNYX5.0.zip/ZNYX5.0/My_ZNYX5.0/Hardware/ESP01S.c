#include "stm32f10x.h" // Device header
#include "ESP01S.h"
#include "LED.h"
#include "Delay.h"
#include "OLED.h"
#include "MyRTC.h"
#include "Key.h"
#include "My_Flash.h"
#include "Tick.h"

extern volatile uint8_t deepsleepflag;

uint8_t ESP01S_RxData[amount]={0};

uint32_t espinittime = 0; // ESP初始化时间记录
uint32_t esp_reconnecttime = 0;
volatile uint8_t Initflag = 1;
uint8_t esp_reconnect_flag = 0;
uint8_t esp_reconnect_status = 0;
volatile uint32_t esp_timeout = 0;
volatile uint8_t alarmEnFlag;
void ESP01S_Usart(void)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	USART_InitTypeDef USART_InitStructure;
	USART_InitStructure.USART_BaudRate = 115200;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_Init(USART2, &USART_InitStructure);

	USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);

	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 3;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_Init(&NVIC_InitStructure);

	USART_Cmd(USART2, ENABLE);
}

uint8_t ESP01S_ReceiveByte(void)
{
	while (USART_GetFlagStatus(USART2, USART_FLAG_RXNE) == RESET);
	return USART_ReceiveData(USART2);
}

void ESP01S_SendByte(uint8_t Byte)
{
	USART_SendData(USART2, Byte);
	while (USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET)
		;
}

void ESP01S_SendArray(uint8_t *Array, uint16_t Length)
{
	uint16_t i;
	for (i = 0; i < Length; i++)
	{
		ESP01S_SendByte(Array[i]);
	}
}

void ESP01S_SendString(char *String)
{
	uint8_t i;
	for (i = 0; String[i] != '\0'; i++)
	{
		ESP01S_SendByte(String[i]);
	}
}

uint32_t ESP01S_Pow(uint32_t X, uint32_t Y)
{
	uint32_t Result = 1;
	while (Y--)
	{
		Result *= X;
	}
	return Result;
}

void ESP01S_SendNumber(uint32_t Number, uint8_t Length)
{
	uint8_t i;
	for (i = 0; i < Length; i++)
	{
		ESP01S_SendByte(Number / ESP01S_Pow(10, Length - i - 1) % 10 + '0');
	}
}

int fputc(int ch, FILE *f)
{
	ESP01S_SendByte(ch);
	return ch;
}

void ESP01S_Printf(char *format, ...)
{
	char string[512]; // 定义一个足够大的缓冲区
	va_list arg;
	va_start(arg, format);
	vsprintf(string, format, arg);
	va_end(arg);
	ESP01S_SendString(string);
}

void USART2_IRQHandler(void) // 串口2中断服务程序
{

	static uint8_t pRxPacket = 0;
	 // 检查是否有溢出错误中断
     if (USART_GetITStatus(USART2, USART_IT_ORE) != RESET)
    {
        // 先读取SR寄存器（清除错误标志），然后读取DR寄存器
    
        uint8_t RxData = USART_ReceiveData(USART2); // 读取一次数据，清除错误
        // 然后可以重置接收状态，因为发生了错误
        pRxPacket = 0;
        // 清除ORE中断标志
        USART_ClearITPendingBit(USART2, USART_IT_ORE);
    }
	// 检查帧错误
    if (USART_GetITStatus(USART2, USART_IT_FE) != RESET)
    {
        volatile uint8_t temp = USART_ReceiveData(USART2);
        USART_ClearITPendingBit(USART2, USART_IT_FE);
    }
	
	if (USART_GetITStatus(USART2, USART_IT_RXNE) != RESET)
	{
		uint8_t RxData = USART_ReceiveData(USART2); // 读取接收到的数据

		// 检查缓冲区是否已满
		if (pRxPacket < (amount - 1))
		{
			ESP01S_RxData[pRxPacket] = RxData; // 将接收到的数据存储在缓冲区中
			pRxPacket++;					   // 增加接收状态计数器

			// 检查是否接收到结束字符（例如换行符 '\n'）
			if (RxData == '\n')
			{
				pRxPacket = 0; // 重置接收状态计数器
				if (Initflag == 0)
					esp_Get_Data();
			}
		}
		else
		{
			// 缓冲区溢出，重置状态
			pRxPacket = 0;
		}
        // 注意：读取USART_DR会自动清除RXNE标志，所以下面这行可以省略
        // USART_ClearITPendingBit(USART2, USART_IT_RXNE);
	}

}

/**
 * @brief 判断主字符串中是否包含子字符串
 *
 * @param main_string 主字符串
 * @param substring 子字符串
 * @return int 如果包含子字符串返回1，否则返回0
 */
uint8_t contains_substring(const uint8_t *main_string, const char *substring)
{
	// 如果strstr()返回非空指针，则表示找到了子字符串
	if (strstr((const char *)main_string, substring) != NULL)
	{
		return 1; // 找到子字符串
	}
	else
	{
		return 0; // 未找到子字符串
	}
}

/**
 * @brief 向ESP8266发送指令并等待响应
 *
 * @param str 要发送的指令
 * @param res 期望的响应
 * @return    成功返回0，失败返回1
 */
_Bool esp_Cmd(const char *str, const char *res)
{
	uint16_t timeOut = 2000; // 超时计数器
	memset(ESP01S_RxData, 0, sizeof(ESP01S_RxData));
	ESP01S_Printf("%s\r\n", str);
	while (timeOut--)
	{

		if (contains_substring(ESP01S_RxData, res)) // 如果检索到关键词
		{
			memset(ESP01S_RxData, 0, sizeof(ESP01S_RxData)); // 清空缓存

			return 0;
		}

		Delay_ms(1);
	}
	return 1;
}

/**
 * @brief 初始化ESP8266模块
 *
 * @return void
 */
void esp_Init(void)
{
	Initflag = 1;
	/* 1.复位指令 */
	//	esp_Rst();
	if (esp_Cmd("AT+RST", "OK"))
	{
		Delay_ms(500);
		if (esp_Cmd("AT+RST", "OK"))
		{
			return;
		}
	}
	Delay_ms(500);
	/* 2.设置为station模式 */
	if (esp_Cmd("AT+CWMODE=1", "OK"))
	{
		Delay_ms(500);
		if (esp_Cmd("AT+CWMODE=1", "OK"))
		{
			return;
		}
	}
	Delay_ms(500);
	/* 3.启动DHCP */
	if (esp_Cmd("AT+CWDHCP=1,1", "OK"))
	{
		Delay_ms(500);
		if (esp_Cmd("AT+CWDHCP=1,1", "OK"))
		{
			return;
		}
	}
	Delay_ms(500);

	/* 4.连接热点 */
	if (1 == esp_Cmd("AT+CWJAP=\"www\",\"www123456\"", "OK"))
	{
		if (1 == esp_Cmd("AT+CWJAP=\"www\",\"www123456\"", "OK"))
		{
			return;
		}
	}
	Delay_ms(500);

	/* 5.配置MQTT用户信息 */
	if (esp_Cmd("AT+MQTTUSERCFG=0,1,\"znyx\",\"NA506BXRBK\",\"version=2018-10-31&res=products%2FNA506BXRBK%2Fdevices%2Fznyx&et=1919945104&method=md5&sign=H9KOr8H%2B9lOZnwnW2lTv%2FA%3D%3D\",0,0,\"\"", "OK"))
	{
		if (esp_Cmd("AT+MQTTUSERCFG=0,1,\"znyx\",\"NA506BXRBK\",\"version=2018-10-31&res=products%2FNA506BXRBK%2Fdevices%2Fznyx&et=1919945104&method=md5&sign=H9KOr8H%2B9lOZnwnW2lTv%2FA%3D%3D\",0,0,\"\"", "OK"))
		{
			return;
		}
	}
	Delay_ms(500);

	/* 6.建立MQTT连接 */
	if (esp_Cmd("AT+MQTTCONN=0,\"mqtts.heclouds.com\",1883,1", "OK"))
	{
		if (esp_Cmd("AT+MQTTCONN=0,\"mqtts.heclouds.com\",1883,1", "OK"))
		{
			return;
		}
	}
	Delay_ms(500);

	/* 7.订阅主题 */
	// 主题用于接收服务器对客户端发布消息的回复
	// while (esp_Cmd("AT+MQTTSUB=0,\"$sys/NA506BXRBK/znyx/thing/property/post/reply\",1", "OK"))
	// 	;
	// Delay_ms(500);

	// 主题用于接收服务器发布事件的回复
	// while(esp_Cmd("AT+MQTTSUB=0,\"$sys/NA506BXRBK/znyx/thing/event/post/reply\",1", "OK"));
	// Delay_ms(500);

	// 主题用于接收服务器下发的属性设置命令
	if (esp_Cmd("AT+MQTTSUB=0,\"$sys/NA506BXRBK/znyx/thing/property/set\",1", "OK"))
	{
		Delay_ms(500);
		if (esp_Cmd("AT+MQTTSUB=0,\"$sys/NA506BXRBK/znyx/thing/property/set\",1", "OK"))
		{
			return;
		}
	}
	Delay_ms(500);

	Initflag = 0;
}

void esp_reconnect(void)//重连
{

	switch (esp_reconnect_status)
	{
	case 0:

		memset(ESP01S_RxData, 0, sizeof(ESP01S_RxData));
		ESP01S_Printf("%s\r\n", "AT+RST");

		Initflag = 1;
		esp_reconnect_flag = 1;
		esp_reconnect_status = 1;
		esp_reconnecttime = GetTick();

		break;

	case 1:
		if (GetTick() - esp_reconnecttime < 2000)
			return;
			memset(ESP01S_RxData, 0, sizeof(ESP01S_RxData));
			ESP01S_Printf("%s\r\n", "AT+CWMODE=1");
			esp_reconnect_status = 2;
			esp_reconnecttime = GetTick();
		

		break;
	case 2:
		if (GetTick() - esp_reconnecttime < 2000)
			return;
		if (contains_substring(ESP01S_RxData, "OK"))
		{
			memset(ESP01S_RxData, 0, sizeof(ESP01S_RxData));
			ESP01S_Printf("%s\r\n", "AT+CWDHCP=1,1");
			esp_reconnect_status = 3;
			esp_reconnecttime = GetTick();
		}
		else
		{
			esp_reconnect_flag = 0;
			esp_reconnect_status = 0;
			espinittime = GetTick();
		}

		break;
	case 3:
		if (GetTick() - esp_reconnecttime < 2000)
			return;
		if (contains_substring(ESP01S_RxData, "OK"))
		{
			memset(ESP01S_RxData, 0, sizeof(ESP01S_RxData));
			ESP01S_Printf("%s\r\n", "AT+CWJAP=\"www\",\"www123456\"");
			esp_reconnect_status = 4;
			esp_reconnecttime = GetTick();
		}
		else
		{
			esp_reconnect_flag = 0;
			esp_reconnect_status = 0;
			espinittime = GetTick();
		}

		break;
	case 4:
		if (GetTick() - esp_reconnecttime < 3000)
			return;
		if (contains_substring(ESP01S_RxData, "OK"))
		{
			memset(ESP01S_RxData, 0, sizeof(ESP01S_RxData));
			ESP01S_Printf("%s\r\n", "AT+MQTTUSERCFG=0,1,\"znyx\",\"NA506BXRBK\",\"version=2018-10-31&res=products%2FNA506BXRBK%2Fdevices%2Fznyx&et=1919945104&method=md5&sign=H9KOr8H%2B9lOZnwnW2lTv%2FA%3D%3D\",0,0,\"\"");
			esp_reconnect_status = 5;
			esp_reconnecttime = GetTick();
		}
		else
		{
			esp_reconnect_flag = 0;
			esp_reconnect_status = 0;
			espinittime = GetTick();
		}

		break;
	case 5:
		if (GetTick() - esp_reconnecttime < 2000)
			return;
		if (contains_substring(ESP01S_RxData, "OK"))
		{

			memset(ESP01S_RxData, 0, sizeof(ESP01S_RxData));
			ESP01S_Printf("%s\r\n", "AT+MQTTCONN=0,\"mqtts.heclouds.com\",1883,1");
			esp_reconnect_status = 6;
			esp_reconnecttime = GetTick();
		}
		else
		{
			esp_reconnect_flag = 0;
			esp_reconnect_status = 0;
			espinittime = GetTick();
		}

		break;

	case 6:
		if (GetTick() - esp_reconnecttime < 2000)
			return;
		if (contains_substring(ESP01S_RxData, "OK"))
		{
			memset(ESP01S_RxData, 0, sizeof(ESP01S_RxData));
			ESP01S_Printf("%s\r\n", "AT+MQTTSUB=0,\"$sys/NA506BXRBK/znyx/thing/property/set\",1");
			esp_reconnect_status = 7;
			esp_reconnecttime = GetTick();
		}
		else
		{
			esp_reconnect_flag = 0;
			esp_reconnect_status = 0;
			espinittime = GetTick();
		}

		break;
	case 7:
		if (GetTick() - esp_reconnecttime < 2000)
			return;
		if (contains_substring(ESP01S_RxData, "OK"))
		{
			memset(ESP01S_RxData, 0, sizeof(ESP01S_RxData));
			esp_reconnect_flag = 0;
			esp_reconnect_status = 0;
			espinittime = 0;
			Initflag = 0;
			esp_timeout = 0;
		}
		else
		{
			esp_reconnect_flag = 0;
			esp_reconnect_status = 0;
			espinittime = GetTick();
		}

		break;
	default:
		break;
	}
}

/**
 * @brief 检查接收到的数据中是否包含特定的设备和属性。
 *
 * @param res1 设备名或关键字，用于识别设备。
 * @param res2 属性值，用于识别设备的属性状态。
 * @return int 如果接收到的数据中包含指定的设备和属性，则返回1，否则返回0。
 */
uint8_t esp_Get(const char *res1, const char *res2)
{
	// 示例接收数据格式："+MQTTSUBRECV:0,\"$sys/0S43la9qNI/LED/thing/property/set\",58,{\"id\":\"58\",\"version\":\"1.0\",\"params\":{\"LightSwitch\":false}}"

	/* 检查接收缓冲区中是否包含指定的设备名或关键字 */
	if (1 == contains_substring(ESP01S_RxData, res1))
	{
		/* 如果包含设备名，再检查是否包含指定的属性值 */
		if (1 == contains_substring(ESP01S_RxData, res2))
		{
			return 1; // 找到匹配的设备和属性
		}
	}
	return 0; // 未找到匹配的设备和属性
}

/**
 * @brief 根据接收到的数据设置状态。
 *
 * @return int 返回处理结果，此处没有具体实现返回值，实际应用中可能需要返回状态。
 */
void esp_Get_Timer(void)
{
	if (1 == contains_substring(ESP01S_RxData, "one")) // timer1
	{
		if (1 == contains_substring(ESP01S_RxData, "false"))
		{

			alarmEnFlag = 1;

		}
		else if (1 == contains_substring(ESP01S_RxData, "true"))
		{

			alarmEnFlag = 2;
			
		}
	}
	////////////////////timer2
	else if (1 == contains_substring(ESP01S_RxData, "two"))
	{
		if (1 == contains_substring(ESP01S_RxData, "false"))
		{

			alarmEnFlag = 3;
			
		}
		else if (1 == contains_substring(ESP01S_RxData, "true"))
		{

			alarmEnFlag = 4;
			
		}
	}
	///////////////////timer3
	else if (1 == contains_substring(ESP01S_RxData, "three"))
	{
		if (1 == contains_substring(ESP01S_RxData, "false"))
		{

			alarmEnFlag = 5;
			
		}
		else if (1 == contains_substring(ESP01S_RxData, "true"))
		{

			alarmEnFlag = 6;
			
		}
	}
}

void esp_Change_Timer(void) // 根据标志位改变闹钟使能状态
{
	switch (alarmEnFlag)
	{
	case 0:
		break;

	case 1:
		alarm[0].Enable = 0;
		Store_Data[7][18] = alarm[0].Enable;
		Alarm_Save();
		//			MyFLASH_ProgramHalfWord(STORE_START_ADDRESS+18*2+7*2*20,Store_Data[7][18]);//写之前得擦除和解锁，写不了而且可能会损坏（数据只能从1变成0，擦除后才为1），否则会锁死FPEC,FLASH_CR直到复位(若未解锁）
		alarmEnFlag = 0;
		ESP01S_SendTimerState(alarm[0].Enable,alarm[1].Enable,alarm[2].Enable);
		break;
	case 2:
		alarm[0].Enable = 1;
		alarm[0].Confirm = 0;
		Store_Data[7][19] = alarm[0].Confirm;
		Store_Data[7][18] = alarm[0].Enable;

		Alarm_Save();
		alarmEnFlag = 0;
		ESP01S_SendTimerState(alarm[0].Enable,alarm[1].Enable,alarm[2].Enable);
		break;
	case 3:
		alarm[1].Enable = 0;

		Store_Data[8][18] = alarm[1].Enable;
		Alarm_Save();
		alarmEnFlag = 0;
		ESP01S_SendTimerState(alarm[0].Enable,alarm[1].Enable,alarm[2].Enable);
		break;
	case 4:
		alarm[1].Enable = 1;
		alarm[1].Confirm = 0;
		Store_Data[8][19] = alarm[1].Confirm;
		Store_Data[8][18] = alarm[1].Enable;
		Alarm_Save();
		alarmEnFlag = 0;

		ESP01S_SendTimerState(alarm[0].Enable,alarm[1].Enable,alarm[2].Enable);
		break;
	case 5:
		alarm[2].Enable = 0;
		Store_Data[9][18] = alarm[2].Enable;
		Alarm_Save();
		alarmEnFlag = 0;
		ESP01S_SendTimerState(alarm[0].Enable,alarm[1].Enable,alarm[2].Enable);
		break;
	case 6:
		alarm[2].Enable = 1;
		alarm[2].Confirm = 0;
		Store_Data[9][19] = alarm[2].Confirm;
		Store_Data[9][18] = alarm[2].Enable;
		Alarm_Save();
		alarmEnFlag = 0;
		ESP01S_SendTimerState(alarm[0].Enable,alarm[1].Enable,alarm[2].Enable);
		break;
	}
}

void esp_Get_Data(void) /*处理接收到的数据*/
{
	if (contains_substring(ESP01S_RxData, "ERROR"))
	{
		esp_timeout++;
	}
	else if (contains_substring(ESP01S_RxData, "set"))
	{
		esp_Get_Timer();
	}
    memset(ESP01S_RxData, 0, sizeof(ESP01S_RxData));
	// 清空接收缓冲区
}

/**
 * @brief 发布温度到 MQTT 服务器
 * @param temp 要发布的温度值
 */
// void ESP01S_SendTemp(uint8_t temp)
//{
//     // 1. 定义足够大的缓冲区，存储拼接后的指令
//     char mqtt_cmd[256];  // 确保能装下完整指令（JSON+MQTT指令）
//
//     // 2. 动态拼接 MQTT 发布指令：把 temp 变量拼到 JSON 的 value 里
//     // 格式：AT+MQTTPUB=0,"主题","{\"id\":\"123\",\"params\":{\"temp\":{\"value\":temp值}}}",0,0
//     sprintf(mqtt_cmd,
//             "AT+MQTTPUB=0,\"$sys/NA506BXRBK/znyx/thing/property/post\",\"{\\\"id\\\":\\\"123\\\"\\,\\\"params\\\":{\\\"temp\\\":{\\\"value\\\":%d}}}\",0,0",
//             temp);  // %.1f 表示保留1位小数，根据需求改（比如 %.2f 保留2位）
//
//     // 3. 调用 esp_Cmd 发送指令，等待 "success" 响应
//    while( esp_Cmd(mqtt_cmd, "success"));
// }

/**
 * @brief 发布湿度到 MQTT 服务器
 * @param humi 要发布的湿度值
 */
// void ESP01S_SendHumi(uint8_t humi)
//{
//     char mqtt_cmd[256];
//
//     sprintf(mqtt_cmd,
//             "AT+MQTTPUB=0,\"$sys/NA506BXRBK/znyx/thing/property/post\",\"{\\\"id\\\":\\\"123\\\"\\,\\\"params\\\":{\\\"humi\\\":{\\\"value\\\":%d}}}\",0,0",
//             humi);
//
//     while(esp_Cmd(mqtt_cmd, "success"));
// }

// void ESP01S_SendWeight(float weight)
//{
//     char mqtt_cmd[256];
//
//     sprintf(mqtt_cmd,
//             "AT+MQTTPUB=0,\"$sys/NA506BXRBK/znyx/thing/property/post\",\"{\\\"id\\\":\\\"123\\\"\\,\\\"params\\\":{\\\"weight\\\":{\\\"value\\\":%.1f}}}\",0,0",
//             weight);
//
//     while(esp_Cmd(mqtt_cmd, "success"));
// }

// void ESP01S_SendRecord(char str[])
//{
//     char mqtt_cmd[256];
//
//     sprintf(mqtt_cmd,
//             "AT+MQTTPUB=0,\"$sys/NA506BXRBK/znyx/thing/property/post\",\"{\\\"id\\\":\\\"123\\\"\\,\\\"params\\\":{\\\"record\\\":{\\\"value\\\":\\\"%s\\\"}}}\",0,0",
//             str);
//
//     while(esp_Cmd(mqtt_cmd, "success"));
// }


/**
 * @brief 发布药箱状态到 MQTT 服务器
 //失败的，一次无法发送太多，只能分开
 */
void ESP01S_SendState(uint8_t temp, uint8_t humi, uint16_t weight, char newrecord[],uint8_t one)
{
	char mqtt_cmd[384];

	sprintf(mqtt_cmd,
			"AT+MQTTPUB=0,\"$sys/NA506BXRBK/znyx/thing/property/post\",\"{\\\"id\\\":\\\"123\\\"\\,\\\"params\\\":{\\\"temp\\\":{\\\"value\\\":%d}\\,\\\"humi\\\":{\\\"value\\\":%d}\\,\\\"weight\\\":{\\\"value\\\":%d}\\,\\\"record\\\":{\\\"value\\\":\\\"%s\\\"}\\,\\\"one\\\":{\\\"value\\\":%s}}}\",0,0",
			temp, humi, weight, newrecord,one ? "true" : "false");

	ESP01S_Printf("%s\r\n", mqtt_cmd);
}
/**
 * @brief 发布药箱状态到 MQTT 服务器
 * @param temp 温度值
 * @param humi 湿度值
 * @param weight 药品重量
 * @param newrecord 服药记录字符串
 */
void ESP01S_SendMedState(uint8_t temp, uint8_t humi, uint16_t weight, char newrecord[])
{
	char mqtt_cmd[256];

	sprintf(mqtt_cmd,
			"AT+MQTTPUB=0,\"$sys/NA506BXRBK/znyx/thing/property/post\",\"{\\\"id\\\":\\\"123\\\"\\,\\\"params\\\":{\\\"temp\\\":{\\\"value\\\":%d}\\,\\\"humi\\\":{\\\"value\\\":%d}\\,\\\"weight\\\":{\\\"value\\\":%d}\\,\\\"record\\\":{\\\"value\\\":\\\"%s\\\"}}}\",0,0",
			temp, humi, weight, newrecord);

	ESP01S_Printf("%s\r\n", mqtt_cmd);
}

void ESP01S_SendTimerState(uint8_t one,uint8_t two,uint8_t three)
{
	char mqtt_cmd[256];

	sprintf(mqtt_cmd,
			"AT+MQTTPUB=0,\"$sys/NA506BXRBK/znyx/thing/property/post\",\"{\\\"id\\\":\\\"123\\\"\\,\\\"params\\\":{\\\"one\\\":{\\\"value\\\":%s}\\,\\\"two\\\":{\\\"value\\\":%s}\\,\\\"three\\\":{\\\"value\\\":%s}}}\",0,0",
			one ? "true" : "false",two ? "true" : "false",three ? "true" : "false");

	ESP01S_Printf("%s\r\n", mqtt_cmd);
}

/**
 * @brief 发布闹钟状态到 MQTT 服务器
 * @param one 定时器1状态
 */
void ESP01S_SendTimer1State(uint8_t one)
{
	char mqtt_cmd[256];

	sprintf(mqtt_cmd,
			"AT+MQTTPUB=0,\"$sys/NA506BXRBK/znyx/thing/property/post\",\"{\\\"id\\\":\\\"123\\\"\\,\\\"params\\\":{\\\"one\\\":{\\\"value\\\":%s}}}\",0,0",
			one ? "true" : "false");

	ESP01S_Printf("%s\r\n", mqtt_cmd);
}

void ESP01S_SendTimer2State(uint8_t two)
{
	char mqtt_cmd[256];

	sprintf(mqtt_cmd,
			"AT+MQTTPUB=0,\"$sys/NA506BXRBK/znyx/thing/property/post\",\"{\\\"id\\\":\\\"123\\\"\\,\\\"params\\\":{\\\"two\\\":{\\\"value\\\":%s}}}\",0,0",
			two ? "true" : "false");

	ESP01S_Printf("%s\r\n", mqtt_cmd);
}
void ESP01S_SendTimer3State(uint8_t three)
{
	char mqtt_cmd[256];

	sprintf(mqtt_cmd,
			"AT+MQTTPUB=0,\"$sys/NA506BXRBK/znyx/thing/property/post\",\"{\\\"id\\\":\\\"123\\\"\\,\\\"params\\\":{\\\"three\\\":{\\\"value\\\":%s}}}\",0,0",
			three ? "true" : "false");

	ESP01S_Printf("%s\r\n", mqtt_cmd);
}
/**
 * @brief 发布药箱异常状态到 MQTT 服务器
 * @param nogood 药箱环境异常状态
 * @param notake 未服药状态
 * @param noenough 药品不足状态
 */
void ESP01S_SendNoGood(uint8_t nogood)
{
	char mqtt_cmd[256];

	sprintf(mqtt_cmd,
			"AT+MQTTPUB=0,\"$sys/NA506BXRBK/znyx/thing/property/post\",\"{\\\"id\\\":\\\"123\\\"\\,\\\"params\\\":{\\\"nogood\\\":{\\\"value\\\":%s}}}\",0,0",
			nogood ? "true" : "false");

	ESP01S_Printf("%s\r\n", mqtt_cmd);
}

void ESP01S_SendNotake(uint8_t notake)
{
	char mqtt_cmd[256];

	sprintf(mqtt_cmd,
			"AT+MQTTPUB=0,\"$sys/NA506BXRBK/znyx/thing/property/post\",\"{\\\"id\\\":\\\"123\\\"\\,\\\"params\\\":{\\\"notake\\\":{\\\"value\\\":%s}}}\",0,0",
			notake ? "true" : "false");

	ESP01S_Printf("%s\r\n", mqtt_cmd);
}
void ESP01S_SendNoEnough(uint8_t noenough)
{
	char mqtt_cmd[256];

	sprintf(mqtt_cmd,
			"AT+MQTTPUB=0,\"$sys/NA506BXRBK/znyx/thing/property/post\",\"{\\\"id\\\":\\\"123\\\"\\,\\\"params\\\":{\\\"noenough\\\":{\\\"value\\\":%s}}}\",0,0",
			noenough ? "true" : "false");

	ESP01S_Printf("%s\r\n", mqtt_cmd);
}

// void ESP01S_SendEvent(MediBoxState mediBoxState)
//{
//	char str[48];
//     char mqtt_cmd[256];
//     sprintf(str,"%04d-%02d-%02d %02d:%02d:%02d %s",
//	now_time[0],
//	now_time[1],
//	now_time[2],
//	now_time[3],
//	now_time[4],
//	now_time[5],
//	(mediBoxState==takeMedicine)?"未服药":(mediBoxState==tempHigh|mediBoxState==humiHigh)?"药箱环境异常":"药品不足");
//     sprintf(mqtt_cmd,
//	"AT+MQTTPUB=0,\"$sys/NA506BXRBK/znyx/thing/event/post\",\"{\\\"id\\\":\\\"321\\\"\\,\\\"params\\\":{\\\"warn\\\":{\\\"value\\\":{\\\"warntype\\\":\\\"%s\\\"}}}}\",0,0",
//             str);
//     while(esp_Cmd(mqtt_cmd, "success"));

//}
