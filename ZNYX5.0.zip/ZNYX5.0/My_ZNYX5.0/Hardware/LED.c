#include "stm32f10x.h" // Device header
_Bool Led_Status = 0;
void LED_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);

	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	GPIO_SetBits(GPIOB, GPIO_Pin_8);

	//  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);

	//  GPIO_InitTypeDef GPIO_InitStructure1;
	//  GPIO_InitStructure1.GPIO_Mode = GPIO_Mode_Out_PP;
	//  GPIO_InitStructure1.GPIO_Pin = GPIO_Pin_13;
	//  GPIO_InitStructure1.GPIO_Speed = GPIO_Speed_50MHz;
	//  GPIO_Init(GPIOC, &GPIO_InitStructure1);

	//  GPIO_SetBits(GPIOC, GPIO_Pin_13);
}

void LED1_ON(void)
{
	GPIO_ResetBits(GPIOB, GPIO_Pin_8);
	Led_Status = 1;
}

void LED1_OFF(void)
{
	GPIO_SetBits(GPIOB, GPIO_Pin_8);
	Led_Status = 0;
}

void LED1_Turn(void)
{
	if (GPIO_ReadOutputDataBit(GPIOB, GPIO_Pin_8) == 0)
	{
		GPIO_SetBits(GPIOB, GPIO_Pin_8);
	}
	else
	{
		GPIO_ResetBits(GPIOB, GPIO_Pin_8);
	}
}

void led2_Turn(void)
{
	if (GPIO_ReadOutputDataBit(GPIOC, GPIO_Pin_13) == 0)
	{
		GPIO_SetBits(GPIOC, GPIO_Pin_13);
	}
	else
	{
		GPIO_ResetBits(GPIOC, GPIO_Pin_13);
	}
}
void LowPower_ON(void)
{
	// GPIO_ResetBits(GPIOC, GPIO_Pin_13);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, DISABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, DISABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, DISABLE);

	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, DISABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, DISABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, DISABLE);

}

void LowPower_OFF(void)
{
	// GPIO_SetBits(GPIOC, GPIO_Pin_13);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);

	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);
}
