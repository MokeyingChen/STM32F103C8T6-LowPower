#include "stm32f10x.h" // Device header
#include <stdio.h>
#include "Delay.h"
#include "Key.h"
#include "BtnTIM.h"
#include "MyRTC.h"
#include "OLED.h"
#include "JQ8900.h"
#include "LED.h"
#include "My_Flash.h"
#include "ESP01S.h"
#include "HX711.h"

extern volatile uint8_t deepsleepflag;
extern uint8_t oledstate;
extern uint32_t last_operation_time;

/**************************key2左边按键(在正常界面下按下跳转到定时（timer）界面)*************************************/
uint8_t notakeflag;
uint8_t notake;
uint8_t timerFlags = 0;
TimerUse timerUse;
TimerUse Warningtimer;
Alarm alarm[5] = {0};
volatile BtnState key1state = Unpressed;
TimingState timingState = Hour;
void Key_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);

	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource11);

	EXTI_InitTypeDef EXTI_InitStructure;
	EXTI_InitStructure.EXTI_Line = EXTI_Line11;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStructure);

	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 6;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}

void EXTI15_10_IRQHandler(void)
{
	// 检查是否是 EXTI5 中断
	if (EXTI_GetITStatus(EXTI_Line11) != RESET)
	{
		// 1. 清除中断标志
		EXTI_ClearITPendingBit(EXTI_Line11);
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
		keyflags = Key1;
		// 2. 关闭外部中断（防止抖动期间多次触发）
		EXTI->IMR &= ~EXTI_Line11;
        EXTI->IMR &= ~EXTI_Line12;
		// 3. 启动定时器（开始 20ms 消抖）
		TIM_SetCounter(BtnTIM_TIM, 0);
		TIM_ITConfig(BtnTIM_TIM, TIM_IT_Update, ENABLE);
		TIM_Cmd(BtnTIM_TIM, ENABLE);
	}

	if (EXTI_GetITStatus(EXTI_Line12) != RESET)
	{
		// 1. 清除中断标志
		EXTI_ClearITPendingBit(EXTI_Line12);
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
		keyflags = Btn;
		// 2. 关闭外部中断（防止抖动期间多次触发）
		EXTI->IMR &= ~EXTI_Line12; // 清除中断屏蔽寄存器中的Line5使能
        EXTI->IMR &= ~EXTI_Line11;
		// 3. 启动定时器（开始 120ms 消抖）
		TIM_SetCounter(BtnTIM_TIM, 0);
		TIM_ITConfig(BtnTIM_TIM, TIM_IT_Update, ENABLE);
		TIM_Cmd(BtnTIM_TIM, ENABLE);
	}
}

uint8_t Key_get(void)
{

	if (key1state == Pressed) // 判断按键
	{
		key1state = Unpressed;
		Key_Pressed();
		return 1;
	}
	return 0;
}

void Key_Pressed(void)
{
	switch (timestate)
	{
	case Normal:

		timingState = Timer;
		timerUse = Timer1;
		timestate = Timing;
		OLED_Clear();
		break;

	case Setting:

		if (settingState == hour)
		{
			if (memcmp(buffer_time, setting_time, sizeof(setting_time)) != 0) // 判断时间是否更改，若更改则设置时间
			{
				MyRTC_SetTime(setting_time);
			}
			timestate = Normal;
			OLED_ShowInNormal();

			if (thr_buffer[0] != weightInThr | thr_buffer[1] != tempInThr | thr_buffer[2] != humiInThr) // 判断阈值是否更改，若更改则写入存储区
			{
				ThrAdd();
			}
		}
		else
		{
			settingState--;
		}
		break;

	case Timing:

		if (timingState == Timer)
		{
			timestate = Normal;
			OLED_ShowInNormal();
			AlarmAdd();
		}
		else
		{
			//			if((timingState==MedType2&&alarm[timerUse].medType1==None)|(timingState==MedType3&&alarm[timerUse].medType2==None)|
			//				(timingState==MedType4&&alarm[timerUse].medType3==None)|(timingState==Enable&&alarm[timerUse].medType4==None)){
			//				timingState-=4;
			//			}else{
			//			timingState--;
			//			}
			if (timingState == Confirm && alarm[timerUse].medType1 == None)
			{
				timingState = MedType1;
			}
			else if (timingState == Confirm && alarm[timerUse].medType2 == None)
			{
				timingState = MedType2;
			}
			else if (timingState == Confirm && alarm[timerUse].medType3 == None)
			{
				timingState = MedType3;
			}
			else if (timingState == Confirm && alarm[timerUse].medType4 == None)
			{
				timingState = MedType4;
			}
			else
			{
				timingState--;
			}
		}
		break;

	case Warning:

		if (lasttimestate == Normal | lasttimestate == Warning)
		{
			timestate = Normal;
			OLED_ShowInNormal();
		}
		else
		{
			timestate = lasttimestate;
			OLED_Clear();
		}
		break;

	case Record:

		break;

	case Adjust:
		switch (adjustState)
		{
		case volume:
			if (volumeadjust > 0)
			{
				Volume_Dowm();
				volumeadjust--;
			}
			break;

		case tare:
			GetMaoPi();
			break;

		case clearrecord:
			RecordStore_Clear();
			sprintf(newRecord, "%04d-%02d-%02d %02d:%02d %s", Store_Data[1][0],
			Store_Data[1][1],
			Store_Data[1][2],
			Store_Data[1][3],
			Store_Data[1][4], (Store_Data[1][5] == 2) ? "已服" : (Store_Data[1][5] == 1) ? "未服"
																																													 : "无");
			break;

		case cleartimer:
			memset(alarm, 0, sizeof(alarm));
			AlarmAdd();
		}
		break;
	}
}

void Alaem_Check(void)
{

	for (TimerUse i = Timer1; i < 5; i++)// 遍历所有定时器
	{
		if (alarm[i].Enable)
		{
			if (now_time[3] == alarm[i].Hour && now_time[4] == alarm[i].Min && (now_time[5] <= 20))
			{
				alarm[i].Enable = 0;
				timerFlags |= (1 << i);
				alarm[i].TrigTime = RTC_GetCounter();

				Warningtimer = i;
				lasttimestate = timestate;
				timestate = Warning;
				OLED_Clear();

			
			}
		}

		if (timerFlags & (1 << i))
		{
			if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == RESET)// 确认
			{
				timerFlags = 0;
				alarm[i].Confirm = 2;

				// 记录数据
				newdata[0] = now_time[0];
				newdata[1] = now_time[1];
				newdata[2] = now_time[2];
				newdata[3] = now_time[3];
				newdata[4] = now_time[4];
				newdata[5] = alarm[i].Confirm;
				Store_Data[7 + i][18] = alarm[i].Enable;
				Store_Data[7 + i][19] = alarm[i].Confirm;
				Store_Add();
				Alarm_Save();

				
			}

			else if (RTC_GetCounter() - alarm[i].TrigTime >= 10) // 等待一定时间后若没人则关闭报警并标记为未服用
			{
				timerFlags &= ~(1 << i);
				alarm[i].Confirm = 1;
				timestate = lasttimestate;

				// 记录数据
				newdata[0] = now_time[0];
				newdata[1] = now_time[1];
				newdata[2] = now_time[2];
				newdata[3] = now_time[3];
				newdata[4] = now_time[4];
				newdata[5] = alarm[i].Confirm;
				Store_Data[7 + i][18] = alarm[i].Enable;
				Store_Data[7 + i][19] = alarm[i].Confirm;
				Store_Add();
				Alarm_Save();

				notakeflag = 1;

				if (lasttimestate == Normal)
				{
					OLED_ShowInNormal();
				}
				else
				{
					OLED_Clear();
				}
				
			}
		}
	}

	if (timerFlags != 0)
	{
		mediBoxStateFlags |= 1;
		LED1_ON();

	}
	else
	{
		mediBoxStateFlags &= 14;
		LED1_OFF();
		//last_operation_time = GetTick();
	}

	if (notakeflag == 1 && notake == 0 && Initflag == 0)
	{
		ESP01S_SendNotake(1);
		notake = 1;
	}
	else if (notakeflag == 1 && notake == 1 && Initflag == 0)
	{
		ESP01S_SendNotake(0);
		notake = 0;
		notakeflag = 0;
	}
}

void OLED_ShowMed(TimerUse timeruse)
{
	char str[16];
	switch (alarm[timeruse].medType1)
	{
	case None:
		OLED_ShowImage(0, 16, 16, 16, MedImage[None]);
		break;
	case Pill:
		OLED_ShowImage(0, 16, 16, 16, MedImage[Pill]);
		break;
	case Capsule:
		OLED_ShowImage(0, 16, 16, 16, MedImage[Capsule]);
		break;
	case Liquid:
		OLED_ShowImage(0, 16, 16, 16, MedImage[Liquid]);
		break;
	case Particle:
		OLED_ShowImage(0, 16, 16, 16, MedImage[Particle]);
		break;
	case Ointment:
		OLED_ShowImage(0, 16, 16, 16, MedImage[Ointment]);
		break;
	case MedBottle:
		OLED_ShowImage(0, 16, 16, 16, MedImage[MedBottle]);
		break;
	}
	if (alarm[timeruse].medType1 == None)
	{
		alarm[timeruse].medNum1 = '\0';
		alarm[timeruse].medType2 = None;
		alarm[timeruse].medType3 = None;
		alarm[timeruse].medType4 = None;
	}
	if (alarm[timeruse].medNum1 == '\0')
	{
		alarm[timeruse].Dosage1 = 0;
		alarm[timeruse].unitType1 = none;
		OLED_ShowString(16, 16, "    ", 8);
	}
	else
	{
		OLED_ShowChar(16, 16, alarm[timeruse].medNum1, 8);
		sprintf(str, ":%02d", alarm[timeruse].Dosage1);
		OLED_ShowString(24, 16, str, 8);
	}

	switch (alarm[timeruse].unitType1)
	{
	case none:
		OLED_ShowImage(48, 16, 16, 16, UnitImaga[none]);
		break;
	case Piece:
		OLED_ShowImage(48, 16, 16, 16, UnitImaga[Piece]);
		break;
	case Grain:
		OLED_ShowImage(48, 16, 16, 16, UnitImaga[Grain]);
		break;
	case Bag:
		OLED_ShowImage(48, 16, 16, 16, UnitImaga[Bag]);
		break;
	case Vial:
		OLED_ShowImage(48, 16, 16, 16, UnitImaga[Vial]);
		break;
	case Gram:
		OLED_ShowImage(48, 16, 16, 16, UnitImaga[Gram]);
		break;
	case Milliliter:
		OLED_ShowImage(48, 16, 16, 16, UnitImaga[Milliliter]);
		break;
	}

	switch (alarm[timeruse].medType2)
	{
	case None:
		OLED_ShowImage(64, 16, 16, 16, MedImage[None]);
		break;
	case Pill:
		OLED_ShowImage(64, 16, 16, 16, MedImage[Pill]);
		break;
	case Capsule:
		OLED_ShowImage(64, 16, 16, 16, MedImage[Capsule]);
		break;
	case Liquid:
		OLED_ShowImage(64, 16, 16, 16, MedImage[Liquid]);
		break;
	case Particle:
		OLED_ShowImage(64, 16, 16, 16, MedImage[Particle]);
		break;
	case Ointment:
		OLED_ShowImage(64, 16, 16, 16, MedImage[Ointment]);
		break;
	case MedBottle:
		OLED_ShowImage(64, 16, 16, 16, MedImage[MedBottle]);
		break;
	}
	if (alarm[timeruse].medType2 == None)
	{
		alarm[timeruse].medNum2 = '\0';
		alarm[timeruse].medType3 = None;
		alarm[timeruse].medType4 = None;
	}
	if (alarm[timeruse].medNum2 == '\0')
	{
		alarm[timeruse].Dosage2 = 0;
		alarm[timeruse].unitType2 = none;
		OLED_ShowString(80, 16, "    ", 8);
	}
	else
	{
		OLED_ShowChar(80, 16, alarm[timeruse].medNum2, 8);
		sprintf(str, ":%02d", alarm[timeruse].Dosage2);
		OLED_ShowString(88, 16, str, 8);
	}

	switch (alarm[timeruse].unitType2)
	{
	case none:
		OLED_ShowImage(112, 16, 16, 16, UnitImaga[none]);
		break;
	case Piece:
		OLED_ShowImage(112, 16, 16, 16, UnitImaga[Piece]);
		break;
	case Grain:
		OLED_ShowImage(112, 16, 16, 16, UnitImaga[Grain]);
		break;
	case Bag:
		OLED_ShowImage(112, 16, 16, 16, UnitImaga[Bag]);
		break;
	case Vial:
		OLED_ShowImage(112, 16, 16, 16, UnitImaga[Vial]);
		break;
	case Gram:
		OLED_ShowImage(112, 16, 16, 16, UnitImaga[Gram]);
		break;
	case Milliliter:
		OLED_ShowImage(112, 16, 16, 16, UnitImaga[Milliliter]);
		break;
	}

	switch (alarm[timeruse].medType3)
	{
	case None:
		OLED_ShowImage(0, 32, 16, 16, MedImage[None]);
		break;
	case Pill:
		OLED_ShowImage(0, 32, 16, 16, MedImage[Pill]);
		break;
	case Capsule:
		OLED_ShowImage(0, 32, 16, 16, MedImage[Capsule]);
		break;
	case Liquid:
		OLED_ShowImage(0, 32, 16, 16, MedImage[Liquid]);
		break;
	case Particle:
		OLED_ShowImage(0, 32, 16, 16, MedImage[Particle]);
		break;
	case Ointment:
		OLED_ShowImage(0, 32, 16, 16, MedImage[Ointment]);
		break;
	case MedBottle:
		OLED_ShowImage(0, 32, 16, 16, MedImage[MedBottle]);
		break;
	}

	if (alarm[timeruse].medType3 == None)
	{
		alarm[timeruse].medNum3 = '\0';
		alarm[timeruse].medType4 = None;
	}
	if (alarm[timeruse].medNum3 == '\0')
	{
		alarm[timeruse].Dosage3 = 0;
		alarm[timeruse].unitType3 = none;
		OLED_ShowString(16, 32, "    ", 8);
	}
	else
	{
		OLED_ShowChar(16, 32, alarm[timeruse].medNum3, 8);
		sprintf(str, ":%02d", alarm[timeruse].Dosage3);
		OLED_ShowString(24, 32, str, 8);
	}

	switch (alarm[timeruse].unitType3)
	{
	case none:
		OLED_ShowImage(48, 32, 16, 16, UnitImaga[none]);
		break;
	case Piece:
		OLED_ShowImage(48, 32, 16, 16, UnitImaga[Piece]);
		break;
	case Grain:
		OLED_ShowImage(48, 32, 16, 16, UnitImaga[Grain]);
		break;
	case Bag:
		OLED_ShowImage(48, 32, 16, 16, UnitImaga[Bag]);
		break;
	case Vial:
		OLED_ShowImage(48, 32, 16, 16, UnitImaga[Vial]);
		break;
	case Gram:
		OLED_ShowImage(48, 32, 16, 16, UnitImaga[Gram]);
		break;
	case Milliliter:
		OLED_ShowImage(48, 32, 16, 16, UnitImaga[Milliliter]);
		break;
	}

	switch (alarm[timeruse].medType4)
	{
	case None:
		OLED_ShowImage(64, 32, 16, 16, MedImage[None]);
		break;
	case Pill:
		OLED_ShowImage(64, 32, 16, 16, MedImage[Pill]);
		break;
	case Capsule:
		OLED_ShowImage(64, 32, 16, 16, MedImage[Capsule]);
		break;
	case Liquid:
		OLED_ShowImage(64, 32, 16, 16, MedImage[Liquid]);
		break;
	case Particle:
		OLED_ShowImage(64, 32, 16, 16, MedImage[Particle]);
		break;
	case Ointment:
		OLED_ShowImage(64, 32, 16, 16, MedImage[Ointment]);
		break;
	case MedBottle:
		OLED_ShowImage(64, 32, 16, 16, MedImage[MedBottle]);
		break;
	}

	if (alarm[timeruse].medType4 == None)
	{
		alarm[timeruse].medNum4 = '\0';
	}
	if (alarm[timeruse].medNum4 == '\0')
	{
		alarm[timeruse].Dosage4 = 0;
		alarm[timeruse].unitType4 = none;
		OLED_ShowString(80, 32, "    ", 8);
	}
	else
	{
		OLED_ShowChar(80, 32, alarm[timeruse].medNum4, 8);
		sprintf(str, ":%02d", alarm[timeruse].Dosage4);
		OLED_ShowString(88, 32, str, 8);
	}

	switch (alarm[timeruse].unitType4)
	{
	case none:
		OLED_ShowImage(112, 32, 16, 16, UnitImaga[none]);
		break;
	case Piece:
		OLED_ShowImage(112, 32, 16, 16, UnitImaga[Piece]);
		break;
	case Grain:
		OLED_ShowImage(112, 32, 16, 16, UnitImaga[Grain]);
		break;
	case Bag:
		OLED_ShowImage(112, 32, 16, 16, UnitImaga[Bag]);
		break;
	case Vial:
		OLED_ShowImage(112, 32, 16, 16, UnitImaga[Vial]);
		break;
	case Gram:
		OLED_ShowImage(112, 16, 16, 16, UnitImaga[Gram]);
		break;
	case Milliliter:
		OLED_ShowImage(112, 32, 16, 16, UnitImaga[Milliliter]);
		break;
	}
}
