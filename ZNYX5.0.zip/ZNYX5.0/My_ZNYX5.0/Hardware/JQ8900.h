#ifndef __JQ8900_H
#define __JQ8900_H

typedef enum{takeMedicine=0x01,tempHigh=0x02,humiHigh=0x04,medicineNoEnough=0x08}MediBoxState;

extern uint8_t mediBoxStateFlags;
extern int8_t volumeadjust;
void JQ8900_Init(void);

void JQ8900_SendByte(uint8_t Byte);
void JQ8900_SendArray(uint8_t *Array,uint16_t Length);
void JQ8900_SendString(char *String);

void JQ8900_ReportStates(void);

void Volume_Plus(void);
void Volume_Dowm(void);
#endif

