#ifndef __KEY_H
#define __KEY_H
#include "encoder.h"

typedef enum{None,Pill,Capsule,Liquid,Particle,Ointment,MedBottle}MedType;//无，药片，胶囊，(液体)口服液，颗粒，药膏，药瓶（可以用图片代替16*16）
typedef enum{none,Piece,Grain,Bag,Vial,Gram,Milliliter}UnitType;//无，片，粒，袋，支，克，毫升
typedef enum {Timer1,Timer2,Timer3,Timer4,Timer5}TimerUse;
 typedef enum{  Timer,Hour,Min,Enable,
	            MedType1,MedNum1,Dosage1,UnitType1,
	            MedType2,MedNum2,Dosage2,UnitType2,
	            MedType3,MedNum3,Dosage3,UnitType3,
	            MedType4,MedNum4,Dosage4,UnitType4,
                Confirm}TimingState;//定时状态
typedef struct{int8_t Hour;int8_t Min;
                 MedType medType1;char medNum1;int8_t Dosage1;UnitType unitType1;
	             MedType medType2;char medNum2;int8_t Dosage2;UnitType unitType2;
	             MedType medType3;char medNum3;int8_t Dosage3;UnitType unitType3;
	             MedType medType4;char medNum4;int8_t Dosage4;UnitType unitType4;
               uint8_t Enable;int8_t Confirm;uint32_t TrigTime;}Alarm;

extern uint8_t timerFlags;
extern TimerUse Warningtimer;
extern TimerUse timerUse;
extern Alarm alarm[5];
 extern volatile BtnState key1state;
 extern TimingState timingState;

void Key_Init(void);
uint8_t Key_get(void);
void Key_Pressed(void);
void Alaem_Check(void);
void OLED_ShowMed(TimerUse timerUse);
#endif
