#ifndef __OLED_H
#define __OLED_H

#include "OLED_Data.h"

void OLED_WriteCommand(uint8_t Command);
void OLED_Update(void);

void OLED_WriteData(uint8_t *Data,uint8_t Count);
void OLED_Init(void);
void OLED_SetCursor(uint8_t x,uint8_t Page);
void OLED_Clear(void);
void OLED_ClearArea(uint8_t x,uint8_t y,uint8_t Width,uint8_t Heigh);
void OLED_ShowChar(uint8_t x,uint8_t y,char Char,uint8_t FontSize);
void OLED_ShowString(uint8_t x,uint8_t y,char *String,uint8_t FontSize);
void OLED_ShowNum(uint8_t x,uint8_t y,uint32_t Number,uint8_t FontSize,uint8_t Length);
void OLED_ShowSignedNum(uint8_t x,uint8_t y,int32_t Number,uint8_t FontSize,uint8_t Length);
void OLED_ShowImage(uint8_t x,uint8_t y,uint8_t Width,uint8_t Heigh,const uint8_t *Image);
void OLED_ShowChinese(uint8_t x,uint8_t y,char *Chinese);
void OLED_DrawPoint(uint8_t x,uint8_t y);
void OLED_ClearPoint(uint8_t x,uint8_t y);
uint8_t OLED_GetPoint(uint8_t x,uint8_t y);
void OLED_DrawLine(uint8_t x0,uint8_t y0,uint8_t x1,uint8_t y1);
void OLED_ClearLine(uint8_t x0,uint8_t y0,uint8_t x1,uint8_t y1);

void OLED_ShowInNormal(void);


void OLED_ShallowSleep_Into(void);
void OLED_ShallowSleep_Out(void);
void OLED_DeepSleep_Into(void);
void OLED_DeepSleep_Out(void);
#endif
