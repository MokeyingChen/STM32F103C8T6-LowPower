#include "stm32f10x.h"                  // Device header
#include "DHT11.h"
#include "Delay.h"


void DHT11_W_DATA(uint8_t BitValue)
{
	GPIO_WriteBit(DHT11_GPIO_PORT, DHT11_GPIO_PIN, (BitAction)BitValue);
}

uint8_t DHT11_R_DATA(void)
{
	return GPIO_ReadInputDataBit(DHT11_GPIO_PORT,DHT11_GPIO_PIN);
}


void DHT11_Init(void)
{
	RCC_APB2PeriphClockCmd(DHT11_GPIO_CLK, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = DHT11_GPIO_PIN;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(DHT11_GPIO_PORT, &GPIO_InitStructure);
	
	DHT11_W_DATA(1);
}

void DHT11_Mode_In(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = DHT11_GPIO_PIN;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(DHT11_GPIO_PORT, &GPIO_InitStructure);
}

void DHT11_Mode_Out(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = DHT11_GPIO_PIN;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(DHT11_GPIO_PORT, &GPIO_InitStructure);

}


void DHT11_Start(void)
{
	DHT11_Mode_Out();
	
	DHT11_W_DATA(0);
	Delay_ms(20);
	
	DHT11_W_DATA(1);
	Delay_us(30);
	
}

uint8_t DHT11_ReceiveAck(void)
{
	uint8_t i;
	DHT11_Mode_In();
	for( i=0;i<100;i++)
	{
		if(DHT11_R_DATA()==0)
		{
		
			break;
		}
		else
		{
			Delay_us(1);
		}
	}
	if(i>=100) return 1;
	else
	{
		for(i=0;i<160;i++)
		{
			if(DHT11_R_DATA()==1)
			{
				
				break;
			}
			else
			{
				Delay_us(1);
			}
		}
	}
	if(i>=160) return 1;
		else return 0;
}

uint8_t DHT11_ReadBit(void)
{
	uint8_t i;
	for( i=0;i<100;i++)
	{
		if(DHT11_R_DATA()==0)
		{
		
			break;
		}
		else
		{
			Delay_us(1);
		}
	}
	
		for(i=0;i<120;i++)
		{
			if(DHT11_R_DATA()==1)
			{
				
				break;
			}
			else
			{
				Delay_us(1);
			}
		}
		
		Delay_us(35);
		
		if(DHT11_R_DATA()==1) return 1;
		else return 0;
		
	}
				
uint8_t DHT11_ReadByte(void)
{
	uint8_t i,data=0;
	for(i=0;i<8;i++)
	{
		data<<=1;
		data|=DHT11_ReadBit();
	}
	return data;
}

uint8_t DHT11_ReadData(uint8_t *temp,uint8_t *humi)
{
	uint8_t i,data[5];
	DHT11_Start();
	if(DHT11_ReceiveAck()==0)
	{
		for(i=0;i<5;i++)
		{
			data[i]=DHT11_ReadByte();
		}
		if(data[0]+data[1]+data[2]+data[3]==data[4])
		{
			*humi=data[0];
			*temp=data[2];
		}
		
	}
	else return 1;
	return 0;
}

