#ifndef __LED_H
#define __LED_H
extern _Bool Led_Status;

void LED_Init(void);
void LED1_ON(void);
void LED1_OFF(void);
void LED1_Turn(void);

void led2_Turn(void);


void LowPower_ON(void);
void LowPower_OFF(void);
#endif
