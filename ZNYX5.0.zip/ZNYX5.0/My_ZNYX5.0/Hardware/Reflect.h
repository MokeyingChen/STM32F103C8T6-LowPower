#ifndef __REFLECT_H
#define __REFLECT_H

void Reflect_Init(void);

#endif
