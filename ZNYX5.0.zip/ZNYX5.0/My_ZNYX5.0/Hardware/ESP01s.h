#ifndef _ESP01S_H
#define _ESP01S_H

#include <stdio.h>
#include <stdarg.h>
#include <string.h>

#include "JQ8900.h"

#define    amount     256

extern uint8_t ESP01S_RxData[amount];
extern uint8_t ESP01S_RxFlag;
extern uint32_t espinittime;
extern volatile uint8_t alarmEnFlag;
extern volatile uint8_t Initflag;
extern uint8_t esp_reconnect_flag;
extern volatile uint32_t esp_timeout;

void ESP01S_Usart(void);
void ESP01S_SendByte(uint8_t Byte);
void ESP01S_SendArray(uint8_t *Array,uint16_t Length);
void ESP01S_SendString(char *String);
void ESP01S_SendNumber(uint32_t Number,uint8_t Length);
void ESP01S_Printf(char *format, ...);
uint8_t ESP01S_ReceiveByte(void);




void esp_Init(void);
void esp_reconnect(void);
_Bool esp_Cmd(const char *str, const char *res);

void esp_Get_Data(void);
void esp_Change_Timer(void);

void ESP01S_SendTemp(uint8_t temp);
void ESP01S_SendHumi(uint8_t humi);
void ESP01S_SendWeight(float weight);
void ESP01S_SendLED(_Bool Led_Status);
void ESP01S_SendRecord(char str[]);

void ESP01S_SendState(uint8_t temp, uint8_t humi, uint16_t weight, char newrecord[],uint8_t one);
void ESP01S_SendMedState(uint8_t temp,uint8_t humi,uint16_t weight,char newrecord[]);
void ESP01S_SendTimerState(uint8_t one,uint8_t two,uint8_t three);
void ESP01S_SendTimer1State(uint8_t one);
void ESP01S_SendTimer2State(uint8_t two);
void ESP01S_SendTimer3State(uint8_t three);
void ESP01S_SendNoGood(uint8_t nogood);
void ESP01S_SendNotake(uint8_t notake);
void ESP01S_SendNoEnough(uint8_t noenough);
//void ESP01S_SendEvent(MediBoxState mediBoxState);
#endif
