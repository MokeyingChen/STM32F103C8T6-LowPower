#include "stm32f10x.h" // Device header
#include "Delay.h"
#include <string.h>
#include "OLED.h"
#include <math.h>

uint8_t OLED_DisplayBuf[8][128];

void MyI2C_W_SCL(uint8_t BitValue)
{
	GPIO_WriteBit(GPIOB, GPIO_Pin_6, (BitAction)BitValue);
}

void MyI2C_W_SDA(uint8_t BitValue)
{
	GPIO_WriteBit(GPIOB, GPIO_Pin_7, (BitAction)BitValue);
}

uint8_t MyI2C_R_SDA(void)
{
	uint8_t BitValue;
	BitValue = GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_7);
	return BitValue;
}

void MyI2C_Start(void)
{
	MyI2C_W_SDA(1);
	MyI2C_W_SCL(1);
	MyI2C_W_SDA(0);
	MyI2C_W_SCL(0);
}

void MyI2C_Stop(void)
{
	MyI2C_W_SDA(0);
	MyI2C_W_SCL(1);
	MyI2C_W_SDA(1);
}

void MyI2C_SendByte(uint8_t Byte)
{
	uint8_t i;
	for (i = 0; i < 8; i++)
	{
		MyI2C_W_SDA(Byte & (0x80 >> i));
		MyI2C_W_SCL(1);
		MyI2C_W_SCL(0);
	}
	MyI2C_W_SCL(1); // 额外的一个时钟，不处理应答信号
	MyI2C_W_SCL(0);
}

uint8_t MyI2C_ReceiveAck(void)
{
	uint8_t AckBit;
	MyI2C_W_SDA(1);
	MyI2C_W_SCL(1);
	AckBit = MyI2C_R_SDA();
	MyI2C_W_SCL(0);
	return AckBit;
}

void I2C_Recover(I2C_TypeDef* I2Cx, uint32_t I2C_SDA_Pin, uint32_t I2C_SCL_Pin, GPIO_TypeDef* GPIOx)
{
    uint32_t i;
    
    // 1. 禁用I2C
    I2C_Cmd(I2Cx, DISABLE);
    
    // 2. 切换为GPIO模式，手动控制SCL产生时钟
    GPIO_InitTypeDef GPIO_InitStruct;
    
    // 配置为开漏输出
    GPIO_InitStruct.GPIO_Pin = I2C_SCL_Pin | I2C_SDA_Pin;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_OD;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOx, &GPIO_InitStruct);
    
    // 3. 确保SDA为高（释放总线）
    GPIO_SetBits(GPIOx, I2C_SDA_Pin);
    Delay_us(5);
    
    // 4. 发送9个时钟脉冲（I2C总线恢复协议）
    for(i = 0; i < 9; i++)
    {
        GPIO_ResetBits(GPIOx, I2C_SCL_Pin);  // SCL低
        Delay_us(5);
        GPIO_SetBits(GPIOx, I2C_SCL_Pin);    // SCL高
        Delay_us(5);
    }
    
    // 5. 发送一个停止条件
    GPIO_ResetBits(GPIOx, I2C_SCL_Pin);
    Delay_us(5);
    GPIO_SetBits(GPIOx, I2C_SDA_Pin);
    Delay_us(5);
    GPIO_SetBits(GPIOx, I2C_SCL_Pin);
    Delay_us(5);
    
    // 6. 重新配置为I2C模式
    GPIO_InitStruct.GPIO_Pin = I2C_SCL_Pin | I2C_SDA_Pin;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_OD;  // 复用开漏
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOx, &GPIO_InitStruct);
    
    // 7. 软件复位I2C
    I2C_DeInit(I2Cx);
    
    // 8. 重新初始化I2C
    I2C_InitTypeDef I2C_InitStructure;
    
    I2C_InitStructure.I2C_Mode = I2C_Mode_I2C;
    I2C_InitStructure.I2C_DutyCycle = I2C_DutyCycle_2;
    I2C_InitStructure.I2C_OwnAddress1 = 0x00;
    I2C_InitStructure.I2C_Ack = I2C_Ack_Enable;
    I2C_InitStructure.I2C_AcknowledgedAddress = I2C_AcknowledgedAddress_7bit;
    I2C_InitStructure.I2C_ClockSpeed = 200000;  
    
    I2C_Init(I2Cx, &I2C_InitStructure);
    I2C_Cmd(I2Cx, ENABLE);
}

 uint8_t OLED_CheckEvent(I2C_TypeDef* I2Cx, uint32_t I2C_EVENT)
{
	uint32_t timeout;
	timeout=7200;
	while(I2C_CheckEvent(I2Cx,I2C_EVENT)==ERROR)
	{
		timeout--;
		if(timeout==0)
		{
			 I2C_Recover(I2C1, GPIO_Pin_7, GPIO_Pin_6, GPIOB);
			return 1;
		}
	}
	return 0;
 }

void OLED_WriteCommand(uint8_t Command)
{
	MyI2C_Start();

	MyI2C_SendByte(0x78);
	////    MyI2C_ReceiveAck();
	MyI2C_SendByte(0x00);
	////    MyI2C_ReceiveAck();
	MyI2C_SendByte(Command);
	//	MyI2C_ReceiveAck();

	MyI2C_Stop();

//	I2C_GenerateSTART(I2C1,ENABLE);
//	if(OLED_CheckEvent(I2C1,I2C_EVENT_MASTER_MODE_SELECT)) return;

//    I2C_Send7bitAddress(I2C1,0x78,I2C_Direction_Transmitter);
//	if(OLED_CheckEvent(I2C1,I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED))return;

//    I2C_SendData(I2C1,0x00);
//	if(OLED_CheckEvent(I2C1,I2C_EVENT_MASTER_BYTE_TRANSMITTING))return;

//    I2C_SendData(I2C1,Command);
//	if(OLED_CheckEvent(I2C1,I2C_EVENT_MASTER_BYTE_TRANSMITTED))return;

//    I2C_GenerateSTOP(I2C1,ENABLE);
}

void OLED_WriteData(uint8_t *Data, uint8_t Count)
{
	MyI2C_Start();

	MyI2C_SendByte(0x78);
	////    MyI2C_ReceiveAck();
	MyI2C_SendByte(0x40);
	////    MyI2C_ReceiveAck();
	for (uint8_t i = 0; i < Count; i++)
	{
		MyI2C_SendByte(Data[i]);
		////	MyI2C_ReceiveAck();
	}

	MyI2C_Stop();

//	I2C_GenerateSTART(I2C1,ENABLE);
//	if(OLED_CheckEvent(I2C1,I2C_EVENT_MASTER_MODE_SELECT))return;

//    I2C_Send7bitAddress(I2C1,0x78,I2C_Direction_Transmitter);
//	if(OLED_CheckEvent(I2C1,I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED))return;

//    I2C_SendData(I2C1,0x40);
//	if(OLED_CheckEvent(I2C1,I2C_EVENT_MASTER_BYTE_TRANSMITTING))return;
//	for(uint8_t i=0;i<Count;i++)
//	{
//    I2C_SendData(I2C1,Data[i]);
//	if(OLED_CheckEvent(I2C1,I2C_EVENT_MASTER_BYTE_TRANSMITTED))return;
//	}


//    I2C_GenerateSTOP(I2C1,ENABLE);
}

void OLED_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);

	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	GPIO_SetBits(GPIOB, GPIO_Pin_6 | GPIO_Pin_7);

//	RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C1,ENABLE);
//	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);

//	GPIO_InitTypeDef GPIO_InitStructure;
//	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF_OD;
//	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_6|GPIO_Pin_7;
//	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
//	GPIO_Init (GPIOB,&GPIO_InitStructure);

//	I2C_InitTypeDef I2C_InitStructure;
//	I2C_InitStructure.I2C_Ack=I2C_Ack_Enable;
//	I2C_InitStructure.I2C_AcknowledgedAddress=I2C_AcknowledgedAddress_7bit;
//	I2C_InitStructure.I2C_ClockSpeed=200000;
//	I2C_InitStructure.I2C_DutyCycle=I2C_DutyCycle_2;
//	I2C_InitStructure.I2C_Mode=I2C_Mode_I2C;
//	I2C_InitStructure.I2C_OwnAddress1=0x00;
//	I2C_Init(I2C1,&I2C_InitStructure);
//	I2C_Cmd(I2C1,ENABLE);
	Delay_ms(100);

	OLED_WriteCommand(0xAE);

	OLED_WriteCommand(0xD5);
	OLED_WriteCommand(0x80);

	OLED_WriteCommand(0xA8);
	OLED_WriteCommand(0x3F);

	OLED_WriteCommand(0xD3);
	OLED_WriteCommand(0x00);

	OLED_WriteCommand(0x40);

	OLED_WriteCommand(0xA1);

	OLED_WriteCommand(0xC8);

	OLED_WriteCommand(0xDA);
	OLED_WriteCommand(0x12);

	OLED_WriteCommand(0x81);
	OLED_WriteCommand(0xCF);

	OLED_WriteCommand(0xD9);
	OLED_WriteCommand(0xF1);

	OLED_WriteCommand(0xDB);
	OLED_WriteCommand(0x30);

	OLED_WriteCommand(0xA4);

	OLED_WriteCommand(0xA6);

	OLED_WriteCommand(0x8D);
	OLED_WriteCommand(0x14);

	OLED_WriteCommand(0xAF);

	Delay_ms(100);
	OLED_Clear();
	OLED_Update();
}

void OLED_ShallowSleep_Into(void)
{
	OLED_WriteCommand(0xAE);

}

void OLED_ShallowSleep_Out(void)
{
	OLED_WriteCommand(0xAF);

}


void OLED_DeepSleep_Into(void)
{
	// 进入休眠
	OLED_WriteCommand(0xAE); // Display Off – 停止像素发光
	OLED_WriteCommand(0x8D);
	OLED_WriteCommand(0x10); // Disable Charge Pump – 关闭升压电路

}

void OLED_DeepSleep_Out(void)
{
	// 退出休眠
	OLED_WriteCommand(0x8D);
	OLED_WriteCommand(0x14); // Enable Charge Pump
    Delay_ms(10);               // 等待电压稳定
	//OLED_WriteCommand(0xAF); // Display On

}



void OLED_SetCursor(uint8_t x, uint8_t Page)
{
	OLED_WriteCommand(0x00 | (x & 0x0F));
	OLED_WriteCommand(0x10 | ((x & 0xF0) >> 4));
	OLED_WriteCommand(0xB0 | Page);
}

void OLED_Update(void)
{
	for (uint8_t j = 0; j < 8; j++)
	{
		OLED_SetCursor(0, j);
		OLED_WriteData(OLED_DisplayBuf[j], 128);
	}
}

void OLED_Clear(void)
{

	for (uint8_t j = 0; j < 8; j++)
	{
		for (uint8_t i = 0; i < 128; i++)
		{
			OLED_DisplayBuf[j][i] = 0x00;
		}
	}
}

void OLED_ClearArea(uint8_t x, uint8_t y, uint8_t Width, uint8_t Heigh)
{
	for (uint8_t j = y; j < y + Heigh; j++)
	{
		for (uint8_t i = x; i < x + Width; i++)
		{

			OLED_DisplayBuf[j / 8][i] &= ~(0x01 << (j % 8));
		}
	}
}

void OLED_ShowChar(uint8_t x, uint8_t y, char Char, uint8_t FontSize)
{
	if (FontSize == 6)
	{

		OLED_ShowImage(x, y, 6, 8, OLED_F6x8[Char - ' ']);
	}

	else if (FontSize == 8)
	{
		OLED_ShowImage(x, y, 8, 16, OLED_F8x16[Char - ' ']);
	}
}

void OLED_ShowString(uint8_t x, uint8_t y, char *String, uint8_t FontSize)
{
	for (uint8_t i = 0; String[i] != '\0'; i++)
	{
		OLED_ShowChar(x + i * FontSize, y, String[i], FontSize);
	}
}

uint32_t OLED_Pow(uint32_t X, uint32_t Y)
{
	uint32_t Result = 1;
	while (Y--)
	{
		Result *= X;
	}
	return Result;
}

void OLED_ShowNum(uint8_t x, uint8_t y, uint32_t Number, uint8_t FontSize, uint8_t Length)
{
	uint8_t i;
	for (i = 0; i < Length; i++)
	{
		OLED_ShowChar(x + i * FontSize, y, Number / OLED_Pow(10, Length - i - 1) % 10 + '0', FontSize);
	}
}

void OLED_ShowSignedNum(uint8_t x, uint8_t y, int32_t Number, uint8_t FontSize, uint8_t Length)
{
	uint8_t i;
	uint32_t Number1;
	if (Number >= 0)
	{
		OLED_ShowChar(x, y, '+', FontSize);
		Number1 = Number;
	}
	else
	{
		OLED_ShowChar(x, y, '-', FontSize);
		Number1 = -Number;
	}
	for (i = 0; i < Length; i++)
	{
		OLED_ShowChar(x + (i + 1) * FontSize, y, Number1 / OLED_Pow(10, Length - i - 1) % 10 + '0', FontSize);
	}
}

void OLED_ShowImage(uint8_t x, uint8_t y, uint8_t Width, uint8_t Heigh, const uint8_t *Image)
{
	OLED_ClearArea(x, y, Width, Heigh);

	for (uint8_t j = 0; j < ((Heigh - 1) / 8 + 1); j++)
	{
		for (uint8_t i = 0; i < Width; i++)
		{
			OLED_DisplayBuf[y / 8 + j][x + i] |= Image[i + Width * j] << (y % 8);
			OLED_DisplayBuf[y / 8 + 1 + j][x + i] |= Image[i + Width * j] >> (8 - y % 8);
		}
	}
}

void OLED_ShowChinese(uint8_t x, uint8_t y, char *Chinese)
{
	char SingleChinese[4] = {0};
	uint8_t pChinese = 0;
	uint8_t j;

	for (uint8_t i = 0; Chinese[i] != '\0'; i++)
	{
		SingleChinese[pChinese] = Chinese[i];
		pChinese++;
		if (pChinese >= 3)
		{
			pChinese = 0;
			for (j = 0; strcmp(OLED_CF16x16[j].Index, " ") != 0; j++)
			{
				if (strcmp(OLED_CF16x16[j].Index, SingleChinese) == 0)
				{
					break;
				}
			}

			OLED_ShowImage(x + ((i + 1) / 3 - 1) * 16, y, 16, 16, OLED_CF16x16[j].Data);
		}
	}
}

void OLED_DrawPoint(uint8_t x, uint8_t y)
{
	OLED_DisplayBuf[y / 8][x] |= 0x01 << (y % 8);
}

void OLED_ClearPoint(uint8_t x, uint8_t y)
{
	OLED_DisplayBuf[y / 8][x] &= ~(0x01 << (y % 8));
}

uint8_t OLED_GetPoint(uint8_t x, uint8_t y)
{
	if (OLED_DisplayBuf[y / 8][x] & 0x01 << (y % 8))
	{
		return 1;
	}
	return 0;
}

void OLED_DrawLine(uint8_t x0, uint8_t y0, uint8_t x1, uint8_t y1)
{
	float k = (float)(y1 - y0) / (x1 - x0);
	uint8_t temp;
	if (fabs(k) < 1)
	{
		if (x0 > x1)
		{
			temp = x0;
			x0 = x1;
			x1 = temp;

			temp = y0;
			y0 = y1;
			y1 = temp;
		}

		for (uint8_t x = x0; x <= x1; x++)
		{
			OLED_DrawPoint(x, round(y0 + (x - x0) * k));
		}
	}
	else
	{
		if (y0 > y1)
		{
			temp = x0;
			x0 = x1;
			x1 = temp;

			temp = y0;
			y0 = y1;
			y1 = temp;
		}

		for (uint8_t y = y0; y <= y1; y++)
		{
			OLED_DrawPoint(round(x0 + (y - y0) / k), y);
		}
	}
}

void OLED_ClearLine(uint8_t x0, uint8_t y0, uint8_t x1, uint8_t y1)
{
	float k = (float)(y1 - y0) / (x1 - x0);
	uint8_t temp;
	if (fabs(k) < 1)
	{
		if (x0 > x1)
		{
			temp = x0;
			x0 = x1;
			x1 = temp;

			temp = y0;
			y0 = y1;
			y1 = temp;
		}

		for (uint8_t x = x0; x <= x1; x++)
		{
			OLED_ClearPoint(x, round(y0 + (x - x0) * k));
		}
	}
	else
	{
		if (y0 > y1)
		{
			temp = x0;
			x0 = x1;
			x1 = temp;

			temp = y0;
			y0 = y1;
			y1 = temp;
		}

		for (uint8_t y = y0; y <= y1; y++)
		{
			OLED_ClearPoint(round(x0 + (y - y0) / k), y);
		}
	}
}

void OLED_ShowInNormal(void)
{
	OLED_Clear();
	OLED_ShowChinese(0, 16, "药品余量");
	OLED_ShowString(64, 16, ":0000g", 8);

	OLED_ShowChinese(0, 32, "温度");
	OLED_ShowString(32, 32, ":00", 8);
	OLED_ShowImage(56, 32, 16, 16, Diode);

	OLED_ShowChinese(0, 48, "湿度");
	OLED_ShowString(32, 48, ":00%RH", 8);
}
