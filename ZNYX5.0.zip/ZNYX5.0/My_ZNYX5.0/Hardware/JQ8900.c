#include "stm32f10x.h"                  // Device header
#include "JQ8900.h"
#include "Tick.h"

extern uint8_t oledstate;
extern uint32_t last_operation_time;

uint8_t mediBoxStateFlags = 0; // 全局变量：存储当前所有异常状态（初始为0，无异常）

const MediBoxState priorityOrder[] = { medicineNoEnough ,tempHigh,humiHigh, takeMedicine};// 优先级从高到低

const uint8_t stateWeight[] = {2, 2, 1, 1};  // 给每个优先级加“重复权重”：高紧急度权重高，多播报
	
const uint8_t priorityCount = sizeof(priorityOrder) / sizeof(priorityOrder[0]);

const uint8_t stateIndex[] = {
    [takeMedicine] = 0,
    [tempHigh] = 1,
    [humiHigh] = 2 ,
    [medicineNoEnough] = 3,};//用于语言播报状态的索引

 uint8_t settingOrder[4][6]={{0xAA, 0x07, 0x02, 0x00, 0x01, 0xB4},//吃药
                             {0xAA, 0x07, 0x02, 0x00, 0x02, 0xB5},//温度高
                             {0xAA, 0x07, 0x02, 0x00, 0x03, 0xB6},//湿度高
                             {0xAA, 0x07, 0x02, 0x00, 0x04, 0xB7}};//缺药

uint8_t VolumeInit[5]={0xAA,0x13,0x01,0x5,0xC3};//初始化时发送调节音量(10)数据包|(AA,13,01):固定指令，(0x5):音量大小，（0xC3):前数据之和的低两位
uint8_t VolumePlus[4]={0xAA,0x14,0x00,0xBE };
uint8_t VolumeDown[4]={0xAA,0x15,0x00,0xBF };
int8_t volumeadjust=5;
void JQ8900_Init(void)
{
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    USART_InitTypeDef USART_InitStructure;
    USART_InitStructure.USART_BaudRate = 9600;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Tx;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_Init(USART3, &USART_InitStructure);
    USART_Cmd(USART3, ENABLE);

    JQ8900_SendArray(VolumeInit, 5); // 设置音量
}

void JQ8900_SendByte(uint8_t Byte)
{
    USART_SendData(USART3, Byte);
    while (USART_GetFlagStatus(USART3, USART_FLAG_TXE) == RESET)
        ;
}

void JQ8900_SendArray(uint8_t *Array, uint16_t Length)
{
    uint16_t i;
    for (i = 0; i < Length; i++)
    {
        JQ8900_SendByte(Array[i]);
    }
}

void JQ8900_SendString(char *String)
{
    uint8_t i;
    for (i = 0; String[i] != '\0'; i++)
    {
        JQ8900_SendByte(String[i]);
    }
}

void JQ8900_ReportStates(void)
{

    static uint8_t nowIndex = 0;  // 记录当前播报的优先级索引（用于分时播报）
    static uint8_t nowWeight = 0; // 当前状态的剩余播报次数
    static uint32_t lastReportTime = 0;
    uint32_t nowTime = GetTick(); // 获取当前时间

    // 延时控制：避免播报指令发送过快（根据语音长度调整，如2秒播报一个）
    if (nowTime - lastReportTime < 2000)
    {
        return;
    }

    //  只在有异常时循环检测（避免死循环）
    uint8_t checkCount = 0; // 防止极端情况下的循环溢出（最多检查一圈）
    while (mediBoxStateFlags != 0 && checkCount < priorityCount)
    {

        // 检查当前状态是否触发
        if (mediBoxStateFlags & priorityOrder[nowIndex])
        {

            // oledstate = 0;
			// last_operation_time = GetTick();

            // 映射指令索引

            JQ8900_SendArray(settingOrder[stateIndex[priorityOrder[nowIndex]]], 6);
            lastReportTime = nowTime;
            nowWeight++;

            // 达到权重次数，切换到下一个状态
            if (nowWeight >= stateWeight[nowIndex])
            {
                nowIndex = (nowIndex + 1) % priorityCount;
                nowWeight = 0;
            }
            return;
        }

        // 当前状态未触发，切换到下一个
        nowIndex = (nowIndex + 1) % priorityCount;
        nowWeight = 0;
        checkCount++;
    }

    // 3. 所有异常都检测完毕（或无异常），重置索引
    nowIndex = 0;
    nowWeight = 0;
}

void Volume_Plus(void)
{
    JQ8900_SendArray(VolumePlus, 4);
}

void Volume_Dowm(void)
{
    JQ8900_SendArray(VolumeDown, 4);
}
