#ifndef __DHT11_H
#define __DHT11_H

#define DHT11_GPIO_PORT   GPIOB
#define DHT11_GPIO_PIN   GPIO_Pin_9
#define DHT11_GPIO_CLK   RCC_APB2Periph_GPIOB


void DHT11_Init(void);
uint8_t DHT11_ReadData(uint8_t *temp,uint8_t *humi);

#endif
