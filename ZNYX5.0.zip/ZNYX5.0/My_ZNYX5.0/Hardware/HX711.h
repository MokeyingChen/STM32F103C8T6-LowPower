#ifndef __HX711_H
#define __HX711_H

#define HX711_GPIO_PORT   GPIOA
#define HX711_SCK_GPIO_PIN   GPIO_Pin_6
#define HX711_DOUT_GPIO_PIN   GPIO_Pin_7
#define HX711_GPIO_CLK   RCC_APB2Periph_GPIOA

extern int32_t TareValue;

void HX711_Init(void);
int32_t HX711_ReadData(void);
float HX711_GetWeights(void);
void GetMaoPi(void);
#endif
