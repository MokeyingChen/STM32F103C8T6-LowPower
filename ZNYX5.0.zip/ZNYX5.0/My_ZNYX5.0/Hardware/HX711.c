#include "stm32f10x.h"                  // Device header
#include "HX711.h"
#include "delay.h"
#include <stdlib.h>

float Weights=100.0;
int32_t Weights_100=8434800;
int32_t TareValue =8394000;
int32_t maopi;
void HX711_W_SCK(uint8_t BitValue)
{
	GPIO_WriteBit(HX711_GPIO_PORT,HX711_SCK_GPIO_PIN,(BitAction)BitValue);
}

uint8_t HX711_R_DOUT(void)
{
	uint8_t BitValue;
	BitValue = GPIO_ReadInputDataBit(HX711_GPIO_PORT, HX711_DOUT_GPIO_PIN);
	return BitValue;
}

void HX711_Init(void)
{
	RCC_APB2PeriphClockCmd(HX711_GPIO_CLK,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = HX711_SCK_GPIO_PIN;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(HX711_GPIO_PORT, &GPIO_InitStructure);
	
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = HX711_DOUT_GPIO_PIN;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(HX711_GPIO_PORT, &GPIO_InitStructure);
	maopi=TareValue;
}

int32_t HX711_ReadData(void)
{
	unsigned long data=0;
	uint8_t i;
	
	HX711_W_SCK(0);
	Delay_us(1);
	while(HX711_R_DOUT());
	Delay_us(1);
	for(i=0;i<24;i++)
	{
		HX711_W_SCK(1);
		Delay_us(1);
		data=data<<1;
		HX711_W_SCK(0);
		Delay_us(1);
		if(HX711_R_DOUT())
		{
			data++;
		}
		
	}
	HX711_W_SCK(1);
	Delay_us(1);
	data=data^0x800000;  

	HX711_W_SCK(0);
	Delay_us(1);
	return data;
}

void GetMaoPi(void)
{

 
     maopi = HX711_ReadData();
        
      
}


float HX711_GetWeights(void)
{
	  int32_t value=0;

	value=HX711_ReadData();

	return (float)(value-maopi)*Weights/(float)(Weights_100-TareValue);
}

