#include "stm32f10x.h"                  // Device header
#include "encoder.h"
#include "BtnTIM.h"
#include "Key.h"

extern volatile uint8_t deepsleepflag;

volatile KeyFlags keyflags;

//实现非阻塞按键
void BtnTIM_Init(void)
{
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);

    TIM_InternalClockConfig(TIM2);

    TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
    TIM_TimeBaseInitStruct.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInitStruct.TIM_Period = 200 - 1; // 延时20ms
    TIM_TimeBaseInitStruct.TIM_Prescaler = 7200 - 1;
    TIM_TimeBaseInitStruct.TIM_RepetitionCounter = 0;

    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseInitStruct);

    TIM_ClearFlag(TIM2, TIM_FLAG_Update);
    TIM_ITConfig(TIM2, TIM_IT_Update, DISABLE);

    NVIC_InitTypeDef NVIC_InitStruct;
    NVIC_InitStruct.NVIC_IRQChannel = TIM2_IRQn;
    NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
    NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 4;
    NVIC_InitStruct.NVIC_IRQChannelSubPriority = 0;

    NVIC_Init(&NVIC_InitStruct);
}

void TIM2_IRQHandler(void)
{

    if (TIM_GetITStatus(BtnTIM_TIM, TIM_IT_Update) != RESET)
    {

        TIM_ClearITPendingBit(BtnTIM_TIM, TIM_IT_Update);

        // 2. 停止定时器
        TIM_Cmd(BtnTIM_TIM, DISABLE);
        TIM_ITConfig(BtnTIM_TIM, TIM_IT_Update, DISABLE);

        switch (keyflags)
        {
        case Btn:
            if (GPIO_ReadInputDataBit(encoder_button_PORT, encoder_button_PIN) == 0)
            {

                btnstate = Pressed;
                
                // 置位标志位
            }
            else
            {
                // 抖动导致的误触发
                btnstate = Unpressed;
            }

            
            break;
        case Key1:
            if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_11) == 0)
            {

                key1state = Pressed;
                // 置位标志位
            }
            else
            {
                // 抖动导致的误触发
                key1state = Unpressed;
            }

            
            break;
        }
		
		// 4. 重新使能外部中断（等待下一次按键）
            EXTI->IMR |= EXTI_Line12;
		// 4. 重新使能外部中断（等待下一次按键）
            EXTI->IMR |= EXTI_Line11;
    }

}
