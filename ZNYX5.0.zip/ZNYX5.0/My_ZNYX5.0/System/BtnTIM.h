#ifndef __BTNTIM_H
#define __BTNTIM_H

#define BtnTIM_TIM  TIM2

typedef enum{Btn,Key1}KeyFlags;
extern volatile KeyFlags keyflags;
void BtnTIM_Init(void);


#endif
