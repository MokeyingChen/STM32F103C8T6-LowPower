#include "stm32f10x.h" // Device header
#include "My_Flash.h"
#include <string.h>
#include <stdio.h>
#include "Key.h"
#include "MyRTC.h"

uint16_t Store_Data[10][20];
uint16_t newdata[20];
char newRecord[32];

void Store_Init(void)
{
	if (My_FLASH_ReadHalfWord(STORE_START_ADDRESS) != 0x5a5a) // 判断是否第一次运行，若是则初始化存储区
	{
		__disable_irq();
		MyFLASH_ErasePages(STORE_START_ADDRESS);				// 擦除存储区
		MyFLASH_ProgramHalfWord(STORE_START_ADDRESS, 0x5a5a);	// 写标志
		MyFLASH_ProgramHalfWord(STORE_START_ADDRESS + 2, 0x28); // 初始温度阈值40
		MyFLASH_ProgramHalfWord(STORE_START_ADDRESS + 4, 0x41); // 初始湿度阈值65
		for (uint8_t i = 3; i < 20; i++)						// 初始包括重量阈值为0
		{
			MyFLASH_ProgramHalfWord(STORE_START_ADDRESS + i * 2, 0x0000);
		}
		for (uint8_t j = 1; j < 7; j++) // 初始化6条记录
		{
			for (uint8_t i = 0; i < 20; i++)
			{
				MyFLASH_ProgramHalfWord(STORE_START_ADDRESS + i * 2 + j * 2 * 20, 0x0000);
			}
		}
		MyFLASH_ErasePages(ALARM_START_ADDRESS);
		for (uint8_t j = 7; j < 10; j++) // 初始化3个闹钟
		{
			for (uint8_t i = 0; i < 20; i++)
			{
				MyFLASH_ProgramHalfWord(ALARM_START_ADDRESS + i * 2 + (j - 7) * 2 * 20, 0x0000);
			}
		}
		__enable_irq(); 
	}
	for (uint8_t j = 0; j < 7; j++) // 读取存储区数据到缓存数组
	{
		for (uint8_t i = 0; i < 20; i++)
		{
			Store_Data[j][i] = My_FLASH_ReadHalfWord(STORE_START_ADDRESS + i * 2 + j * 2 * 20);
		}
	}
	for (uint8_t j = 7; j < 10; j++) // 读取闹钟数据到缓存数组
	{
		for (uint8_t i = 0; i < 20; i++)
		{
			Store_Data[j][i] = My_FLASH_ReadHalfWord(ALARM_START_ADDRESS + i * 2 + (j - 7) * 2 * 20);
		}
	}

	sprintf(newRecord, "%04d-%02d-%02d %02d:%02d %s", Store_Data[1][0],
			Store_Data[1][1],
			Store_Data[1][2],
			Store_Data[1][3],
			Store_Data[1][4],
			(Store_Data[1][5] == 2) ? "已服" : (Store_Data[1][5] == 1) ? "未服"
																	   : "无");
	AlarmInit();
	ThrInit();
}

void Store_Save(void)
{
	__disable_irq();
	MyFLASH_ErasePages(STORE_START_ADDRESS);
	for (uint8_t j = 0; j < 7; j++)
	{
		for (uint8_t i = 0; i < 20; i++)
		{
			MyFLASH_ProgramHalfWord(STORE_START_ADDRESS + i * 2 + j * 2 * 20, Store_Data[j][i]);
		}
	}
	__enable_irq(); 
}
void RecordStore_Clear(void)
{
	for (uint8_t j = 1; j < 7; j++)
	{
		for (uint8_t i = 0; i < 20; i++)
		{
			Store_Data[j][i] = 0x0000;
		}
	}
	Store_Save();
}

void Store_Add(void)
{

	for (uint8_t i = 6; i > 1; i--)
	{
		// 复制前一条记录到当前位置（移位）
		memcpy(Store_Data[i], Store_Data[i - 1], sizeof(Store_Data[0]));
	}
	// 2. 新记录放到最前面（Store_Data[0]）
	memcpy(Store_Data[1], newdata, sizeof(Store_Data[0]));
	Store_Save();
	sprintf(newRecord, "%04d-%02d-%02d %02d:%02d %s", newdata[0], newdata[1], newdata[2], newdata[3], newdata[4], (Store_Data[1][5] == 2) ? "已服" : (Store_Data[1][5] == 1) ? "未服"
																																											 : "无");
}

void Alarm_Save(void)
{
	__disable_irq();
	MyFLASH_ErasePages(ALARM_START_ADDRESS);
	for (uint8_t j = 7; j < 10; j++)
	{
		for (uint8_t i = 0; i < 20; i++)
		{
			MyFLASH_ProgramHalfWord(ALARM_START_ADDRESS + i * 2 + (j - 7) * 2 * 20, Store_Data[j][i]);
		}
	}
	__enable_irq(); 
}

void AlarmAdd(void)
{
	for (uint8_t j = 0; j < 3; j++)
	{

		Store_Data[7 + j][0] = alarm[j].Hour;
		Store_Data[7 + j][1] = alarm[j].Min;
		Store_Data[7 + j][2] = alarm[j].medType1;
		Store_Data[7 + j][3] = alarm[j].medNum1;
		Store_Data[7 + j][4] = alarm[j].Dosage1;
		Store_Data[7 + j][5] = alarm[j].unitType1;
		Store_Data[7 + j][6] = alarm[j].medType2;
		Store_Data[7 + j][7] = alarm[j].medNum2;
		Store_Data[7 + j][8] = alarm[j].Dosage2;
		Store_Data[7 + j][9] = alarm[j].unitType2;
		Store_Data[7 + j][10] = alarm[j].medType3;
		Store_Data[7 + j][11] = alarm[j].medNum3;
		Store_Data[7 + j][12] = alarm[j].Dosage3;
		Store_Data[7 + j][13] = alarm[j].unitType3;
		Store_Data[7 + j][14] = alarm[j].medType4;
		Store_Data[7 + j][15] = alarm[j].medNum4;
		Store_Data[7 + j][16] = alarm[j].Dosage4;
		Store_Data[7 + j][17] = alarm[j].unitType4;
		Store_Data[7 + j][18] = alarm[j].Enable;
		Store_Data[7 + j][19] = alarm[j].Confirm;
	}
	Alarm_Save();
}

void AlarmInit(void)
{
	for (uint8_t j = 0; j < 3; j++)
	{

		alarm[j].Hour = Store_Data[7 + j][0];
		alarm[j].Min = Store_Data[7 + j][1];
		alarm[j].medType1 = Store_Data[7 + j][2];
		alarm[j].medNum1 = Store_Data[7 + j][3];
		alarm[j].Dosage1 = Store_Data[7 + j][4];
		alarm[j].unitType1 = Store_Data[7 + j][5];
		alarm[j].medType2 = Store_Data[7 + j][6];
		alarm[j].medNum2 = Store_Data[7 + j][7];
		alarm[j].Dosage2 = Store_Data[7 + j][8];
		alarm[j].unitType2 = Store_Data[7 + j][9];
		alarm[j].medType3 = Store_Data[7 + j][10];
		alarm[j].medNum3 = Store_Data[7 + j][11];
		alarm[j].Dosage3 = Store_Data[7 + j][12];
		alarm[j].unitType3 = Store_Data[7 + j][13];
		alarm[j].medType4 = Store_Data[7 + j][14];
		alarm[j].medNum4 = Store_Data[7 + j][15];
		alarm[j].Dosage4 = Store_Data[7 + j][16];
		alarm[j].unitType4 = Store_Data[7 + j][17];
		alarm[j].Enable = Store_Data[7 + j][18];
		alarm[j].Confirm = Store_Data[7 + j][19];
	}
}

void ThrInit(void)
{
	tempInThr = Store_Data[0][1];
	humiInThr = Store_Data[0][2];
	weightInThr = Store_Data[0][3];
}

void ThrAdd(void)
{

	Store_Data[0][1] = tempInThr;
	Store_Data[0][2] = humiInThr;
	Store_Data[0][3] = weightInThr;
	Store_Save();
}

uint32_t My_FLASH_ReadWord(uint32_t Address)
{
	return *((__IO uint32_t *)(Address));
}

uint16_t My_FLASH_ReadHalfWord(uint32_t Address)
{
	return *((__IO uint16_t *)(Address));
}

uint8_t My_FLASH_ReadByte(uint32_t Address)
{
	return *((__IO uint8_t *)(Address));
}

void MyFLASH_ErasePages(uint32_t PageAddress)
{
	FLASH_Unlock();

	FLASH_ErasePage(PageAddress);

	FLASH_Lock();
}

void MyFLASH_ProgramWord(uint32_t Address, uint32_t Data)
{
	FLASH_Unlock();

	FLASH_ProgramWord(Address, Data);

	FLASH_Lock();
}

void MyFLASH_ProgramHalfWord(uint32_t Address, uint16_t Data)
{
	FLASH_Unlock();

	FLASH_ProgramHalfWord(Address, Data);

	FLASH_Lock();
}
