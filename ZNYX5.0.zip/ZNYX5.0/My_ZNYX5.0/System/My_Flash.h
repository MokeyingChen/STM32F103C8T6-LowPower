#ifndef __MY_FLASH_H
#define __MY_FLASH_H

#define STORE_START_ADDRESS 0x0800FC00 // 储存6条记录和身份标志和阈值
#define ALARM_START_ADDRESS 0x0800F800 // 储存3个闹钟
extern uint16_t Store_Data[10][20];
extern uint16_t newdata[20];
extern char newRecord[32];

void Store_Init(void);
void Store_Save(void);
void RecordStore_Clear(void);
void Store_Add(void);
void AlarmInit(void);
void AlarmAdd(void);
void Alarm_Save(void);
void ThrInit(void);
void ThrAdd(void);
uint32_t My_FLASH_ReadWord(uint32_t Address);

uint16_t My_FLASH_ReadHalfWord(uint32_t Address);

uint8_t My_FLASH_ReadByte(uint32_t Address);

void MyFLASH_ErasePages(uint32_t PageAddress);
void MyFLASH_ProgramWord(uint32_t Address, uint32_t Data);
void MyFLASH_ProgramHalfWord(uint32_t Address, uint16_t Data);

#endif
