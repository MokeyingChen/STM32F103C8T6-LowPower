#ifndef __MYRTC_H
#define __MYRTC_H

 typedef enum{Normal,Setting,Timing,Warning,Record,Adjust}TimeState;//屏幕状态{普通,设置,定时,报警,记录}
 typedef enum{hour,min,sec,year,mon,mday,weightThr,tempThr,humiThr}SettingState;//设置状态
 typedef enum{volume,tare,clearrecord,cleartimer}AdjustState;
 typedef struct{uint8_t x0;uint8_t y0;uint8_t x1;uint8_t y1;}CursorPosition;//光标位置
 
extern TimeState lasttimestate;
extern int16_t weightInThr;
extern int8_t tempInThr;
extern int8_t humiInThr;
extern uint16_t thr_buffer[3];

extern SettingState settingState; 
extern AdjustState adjustState;
extern TimeState timestate;
extern int16_t now_time[6];
extern int16_t setting_time[6];
extern int16_t buffer_time[6];
 
void MyRTC_Init(void);
void MyRTC_SetTime(int16_t Time[]);
void MyRTC_GetTime(int16_t Time[]);
void MyRTC_ShowTime(int16_t Time[]);
 void MyRTC_ShowCursor(void);

#endif

