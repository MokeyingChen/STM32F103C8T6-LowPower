#ifndef __TICK_H
#define __TICK_H


void Tick_Init(void);
uint32_t GetTick(void);

#endif
